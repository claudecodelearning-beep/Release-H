import json
import subprocess
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from release_h.agent import (
    Agent,
    ExecutionResult,
    mac_session_unlocked,
)
from release_h.agent_queue import QueuePaths, enqueue_start, load_request


FIXED_TIME = datetime(2026, 8, 27, 12, 0, tzinfo=timezone.utc)


class FakeExecutor:
    def __init__(self, exit_code: int = 0, during_run=None) -> None:
        self.exit_code = exit_code
        self.during_run = during_run
        self.calls = 0

    def __call__(self) -> ExecutionResult:
        self.calls += 1
        if self.during_run is not None:
            self.during_run()
        return ExecutionResult(
            exit_code=self.exit_code,
            stdout='[{"action":"layout.displays"}]',
            stderr="",
            started_at="2026-08-27T12:02:00Z",
            finished_at="2026-08-27T12:03:00Z",
        )


class AgentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.paths = QueuePaths.at(Path(self.temporary.name))

    def test_locked_session_leaves_request_pending(self) -> None:
        enqueue_start(self.paths, "req-1", FIXED_TIME)
        executor = FakeExecutor()

        outcome = Agent(self.paths, lambda: False, executor).run_once()

        self.assertEqual(outcome.status, "locked")
        self.assertTrue(self.paths.pending.exists())
        self.assertFalse(self.paths.running.exists())
        self.assertEqual(executor.calls, 0)

    def test_repeated_locked_polling_logs_only_the_state_transition(self) -> None:
        enqueue_start(self.paths, "req-1", FIXED_TIME)
        agent = Agent(self.paths, lambda: False, FakeExecutor())

        agent.run_once()
        agent.run_once()

        lines = self.paths.log.read_text(encoding="utf-8").splitlines()
        self.assertEqual(len(lines), 1)

    def test_unknown_session_state_fails_closed(self) -> None:
        enqueue_start(self.paths, "req-1", FIXED_TIME)
        executor = FakeExecutor()

        outcome = Agent(self.paths, lambda: None, executor).run_once()

        self.assertEqual(outcome.status, "locked")
        self.assertIn("unknown", outcome.detail.lower())
        self.assertEqual(executor.calls, 0)

    def test_unlock_claims_and_executes_exactly_once(self) -> None:
        enqueue_start(self.paths, "req-1", FIXED_TIME)
        executor = FakeExecutor()
        agent = Agent(self.paths, lambda: True, executor)

        first = agent.run_once()
        second = agent.run_once()

        self.assertEqual(first.status, "completed")
        self.assertEqual(second.status, "idle")
        self.assertEqual(executor.calls, 1)
        self.assertFalse(self.paths.running.exists())

    def test_request_arriving_during_run_remains_pending(self) -> None:
        enqueue_start(self.paths, "req-1", FIXED_TIME)

        def enqueue_second() -> None:
            enqueue_start(self.paths, "req-2", FIXED_TIME)

        executor = FakeExecutor(during_run=enqueue_second)
        agent = Agent(self.paths, lambda: True, executor)

        outcome = agent.run_once()

        self.assertEqual(outcome.status, "completed")
        self.assertEqual(load_request(self.paths.pending).request_id, "req-2")
        self.assertEqual(executor.calls, 1)

    def test_failed_workflow_is_recorded_and_agent_can_continue(self) -> None:
        enqueue_start(self.paths, "req-1", FIXED_TIME)
        executor = FakeExecutor(exit_code=1)

        outcome = Agent(self.paths, lambda: True, executor).run_once()

        self.assertEqual(outcome.status, "failed")
        payload = json.loads(self.paths.last_result.read_text(encoding="utf-8"))
        self.assertEqual(payload["execution"]["exit_code"], 1)
        self.assertFalse(self.paths.running.exists())

    def test_malformed_request_never_reaches_executor(self) -> None:
        self.paths.pending.write_text("not-json", encoding="utf-8")
        executor = FakeExecutor()

        outcome = Agent(self.paths, lambda: True, executor).run_once()

        self.assertEqual(outcome.status, "invalid")
        self.assertEqual(executor.calls, 0)
        self.assertEqual(len(list(self.paths.root.glob("*.invalid"))), 1)


class MacSessionProbeTests(unittest.TestCase):
    @staticmethod
    def response(locked: bool) -> subprocess.CompletedProcess[str]:
        lock_value = "Yes" if locked else "No"
        output = (
            '"IOConsoleUsers" = ({'
            '"kCGSSessionOnConsoleKey"=Yes,'
            '"kCGSessionLoginDoneKey"=Yes,'
            f'"CGSSessionScreenIsLocked"={lock_value},'
            '"kCGSSessionUserNameKey"="macuser"})'
        )
        return subprocess.CompletedProcess([], 0, output, "")

    def test_locked_plist_reports_not_unlocked(self) -> None:
        self.assertFalse(mac_session_unlocked(lambda *args, **kwargs: self.response(True)))

    def test_unlocked_plist_reports_unlocked(self) -> None:
        self.assertTrue(mac_session_unlocked(lambda *args, **kwargs: self.response(False)))

    def test_active_logged_in_console_without_lock_key_is_unlocked(self) -> None:
        output = (
            '"IOConsoleUsers" = ({'
            '"kCGSSessionOnConsoleKey"=Yes,'
            '"kCGSessionLoginDoneKey"=Yes,'
            '"kCGSSessionUserNameKey"="macuser"})'
        )
        response = subprocess.CompletedProcess([], 0, output, "")

        self.assertTrue(mac_session_unlocked(lambda *args, **kwargs: response))

    def test_missing_lock_state_reports_unknown(self) -> None:
        response = subprocess.CompletedProcess([], 0, '"IOConsoleUsers" = ()', "")
        self.assertIsNone(mac_session_unlocked(lambda *args, **kwargs: response))

    def test_failed_probe_reports_unknown(self) -> None:
        response = subprocess.CompletedProcess([], 1, "", "failed")
        self.assertIsNone(mac_session_unlocked(lambda *args, **kwargs: response))


if __name__ == "__main__":
    unittest.main()
