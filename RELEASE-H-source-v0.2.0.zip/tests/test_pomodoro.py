import json
import random
import tempfile
import unittest
from pathlib import Path

import release_h.pomodoro as pomodoro_module
from release_h.pomodoro import (
    PomodoroRepository,
    Video,
    choose_video,
    eligible,
    parse_creator_response,
)


class FavoriteFolderSelectionTests(unittest.TestCase):
    def test_selection_covers_configured_pages_and_columns_without_immediate_repeat(self) -> None:
        selector_type = getattr(pomodoro_module, "FavoriteFolderSelector", None)
        self.assertIsNotNone(selector_type, "FavoriteFolderSelector is not implemented")
        if selector_type is None:
            return

        with tempfile.TemporaryDirectory() as directory:
            selector = selector_type(
                folder_name="RELEASE H 番茄钟",
                state_dir=Path(directory),
                max_page_downs=20,
                columns=3,
                rng=random.Random(7),
            )
            plans = [selector.select() for _ in range(40)]

        self.assertTrue(all(plan.folder_name == "RELEASE H 番茄钟" for plan in plans))
        self.assertTrue(all(0 <= plan.page_downs <= 20 for plan in plans))
        self.assertTrue(all(0 <= plan.column < 3 for plan in plans))
        self.assertTrue(all(left != right for left, right in zip(plans, plans[1:])))

    def test_last_position_is_shared_between_command_invocations(self) -> None:
        selector_type = getattr(pomodoro_module, "FavoriteFolderSelector", None)
        self.assertIsNotNone(selector_type, "FavoriteFolderSelector is not implemented")
        if selector_type is None:
            return

        with tempfile.TemporaryDirectory() as directory:
            state_dir = Path(directory)
            first = selector_type(
                "RELEASE H 番茄钟", state_dir, 0, 2, random.Random(1)
            ).select()
            second = selector_type(
                "RELEASE H 番茄钟", state_dir, 0, 2, random.Random(1)
            ).select()

        self.assertNotEqual(first, second)

    def test_selection_still_returns_a_plan_when_state_cannot_be_written(self) -> None:
        selector_type = getattr(pomodoro_module, "FavoriteFolderSelector", None)
        self.assertIsNotNone(selector_type, "FavoriteFolderSelector is not implemented")
        if selector_type is None:
            return

        with tempfile.TemporaryDirectory() as directory:
            blocked_state_dir = Path(directory) / "not-a-directory"
            blocked_state_dir.write_text("occupied", encoding="utf-8")
            selector = selector_type(
                "RELEASE H 番茄钟",
                blocked_state_dir,
                max_page_downs=20,
                columns=3,
                rng=random.Random(2),
            )

            try:
                plan = selector.select()
            except OSError as error:
                self.fail(f"state persistence prevented selection: {error}")

        self.assertEqual(plan.folder_name, "RELEASE H 番茄钟")
        self.assertTrue(0 <= plan.page_downs <= 20)
        self.assertTrue(0 <= plan.column < 3)


class PomodoroSelectionTests(unittest.TestCase):
    def test_filter_accepts_25_and_50_minute_formats(self) -> None:
        videos = [
            Video("BV25", "Minecraft 番茄钟25/5", "u1"),
            Video("BV50", "Study With Me 番茄钟50/10", "u2"),
            Video("BVM", "一小时音乐", "u3"),
        ]

        self.assertEqual([video.bvid for video in eligible(videos)], ["BV25", "BV50"])

    def test_choice_does_not_repeat_when_alternative_exists(self) -> None:
        videos = [
            Video("A", "番茄钟25/5", "a"),
            Video("B", "番茄钟50/10", "b"),
        ]

        selected = choose_video(videos, "A", random.Random(1))

        self.assertEqual(selected.bvid, "B")

    def test_creator_response_parses_public_video_records(self) -> None:
        payload = {
            "code": 0,
            "data": {
                "list": {
                    "vlist": [
                        {"bvid": "BV1", "title": "番茄钟25/5"},
                        {"bvid": "BV2", "title": "番茄钟50/10"},
                    ]
                }
            },
        }

        videos = parse_creator_response(payload)

        self.assertEqual(videos[0].url, "https://www.bilibili.com/video/BV1/")
        self.assertEqual([video.bvid for video in videos], ["BV1", "BV2"])


class PomodoroRepositoryTests(unittest.TestCase):
    def test_web_selection_uses_fallback_when_state_directory_is_unwritable(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            blocked_state_dir = root / "not-a-directory"
            blocked_state_dir.write_text("occupied", encoding="utf-8")
            fallback_path = root / "fallback.json"
            fallback_path.write_text(
                json.dumps(
                    [{"bvid": "WEB", "title": "番茄钟25/5", "url": "web"}]
                )
            )
            repository = PomodoroRepository(
                state_dir=blocked_state_dir,
                fetcher=lambda: (_ for _ in ()).throw(OSError("offline")),
                fallback_path=fallback_path,
                rng=random.Random(1),
            )

            try:
                selected = repository.select()
            except OSError as error:
                self.fail(f"state persistence prevented web selection: {error}")

        self.assertEqual(selected.bvid, "WEB")

    def test_network_result_refreshes_cache_and_last_selection(self) -> None:
        fetched = [
            Video("A", "番茄钟25/5", "a"),
            Video("B", "番茄钟50/10", "b"),
        ]
        with tempfile.TemporaryDirectory() as directory:
            state_dir = Path(directory)
            repository = PomodoroRepository(
                state_dir=state_dir,
                fetcher=lambda: fetched,
                fallback_path=state_dir / "unused.json",
                rng=random.Random(1),
            )

            selected = repository.select()

            cached = json.loads((state_dir / "videos.json").read_text())
            last = (state_dir / "last_bvid.txt").read_text().strip()
        self.assertEqual(len(cached), 2)
        self.assertEqual(last, selected.bvid)

    def test_fetch_failure_uses_existing_cache(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            state_dir = Path(directory)
            state_dir.joinpath("videos.json").write_text(
                json.dumps(
                    [{"bvid": "CACHE", "title": "番茄钟25/5", "url": "cached"}]
                )
            )
            repository = PomodoroRepository(
                state_dir=state_dir,
                fetcher=lambda: (_ for _ in ()).throw(OSError("offline")),
                fallback_path=state_dir / "unused.json",
                rng=random.Random(1),
            )

            selected = repository.select()

        self.assertEqual(selected.bvid, "CACHE")

    def test_fetch_failure_without_cache_uses_packaged_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            state_dir = Path(directory)
            fallback_path = state_dir / "fallback.json"
            fallback_path.write_text(
                json.dumps(
                    [{"bvid": "FALLBACK", "title": "番茄钟50/10", "url": "fallback"}]
                )
            )
            repository = PomodoroRepository(
                state_dir=state_dir / "state",
                fetcher=lambda: (_ for _ in ()).throw(OSError("offline")),
                fallback_path=fallback_path,
                rng=random.Random(1),
            )

            selected = repository.select()

        self.assertEqual(selected.bvid, "FALLBACK")


if __name__ == "__main__":
    unittest.main()
