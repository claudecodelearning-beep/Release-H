import json
import stat
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from release_h.agent_queue import (
    AgentRequest,
    InvalidRequest,
    QueuePaths,
    acquire_agent_lock,
    claim_request,
    enqueue_start,
    load_request,
    recover_interrupted,
    write_result,
)


FIXED_TIME = datetime(2026, 8, 27, 12, 0, tzinfo=timezone.utc)
LATER_TIME = datetime(2026, 8, 27, 12, 1, tzinfo=timezone.utc)


class AgentQueueTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.paths = QueuePaths.at(Path(self.temporary.name))

    def test_enqueue_writes_fixed_schema_and_user_only_mode(self) -> None:
        request = enqueue_start(self.paths, "req-1", FIXED_TIME)

        self.assertEqual(
            request,
            AgentRequest("req-1", "start-work", "2026-08-27T12:00:00Z"),
        )
        self.assertEqual(load_request(self.paths.pending), request)
        self.assertEqual(stat.S_IMODE(self.paths.pending.stat().st_mode), 0o600)
        self.assertEqual(
            json.loads(self.paths.pending.read_text(encoding="utf-8")),
            {
                "request_id": "req-1",
                "action": "start-work",
                "requested_at": "2026-08-27T12:00:00Z",
            },
        )

    def test_repeated_enqueue_coalesces_to_one_marker(self) -> None:
        enqueue_start(self.paths, "req-1", FIXED_TIME)
        enqueue_start(self.paths, "req-2", LATER_TIME)

        self.assertEqual(load_request(self.paths.pending).request_id, "req-2")
        self.assertEqual(len(list(self.paths.root.glob("pending*"))), 1)

    def test_claim_moves_pending_request_to_running(self) -> None:
        expected = enqueue_start(self.paths, "req-1", FIXED_TIME)

        claimed = claim_request(self.paths)

        self.assertEqual(claimed, expected)
        self.assertFalse(self.paths.pending.exists())
        self.assertTrue(self.paths.running.exists())

    def test_claim_rejects_unsupported_action_and_quarantines_it(self) -> None:
        self.paths.root.mkdir(parents=True, exist_ok=True)
        self.paths.pending.write_text(
            json.dumps(
                {
                    "request_id": "req-1",
                    "action": "shell",
                    "requested_at": "2026-08-27T12:00:00Z",
                }
            ),
            encoding="utf-8",
        )

        with self.assertRaises(InvalidRequest):
            claim_request(self.paths)

        self.assertFalse(self.paths.pending.exists())
        self.assertFalse(self.paths.running.exists())
        self.assertEqual(len(list(self.paths.root.glob("*.invalid"))), 1)

    def test_interrupted_running_request_is_recovered(self) -> None:
        expected = enqueue_start(self.paths, "req-1", FIXED_TIME)
        self.assertEqual(claim_request(self.paths), expected)

        recovered = recover_interrupted(self.paths)

        self.assertTrue(recovered)
        self.assertEqual(load_request(self.paths.pending), expected)
        self.assertFalse(self.paths.running.exists())

    def test_result_is_written_atomically_with_user_only_mode(self) -> None:
        request = AgentRequest("req-1", "start-work", "2026-08-27T12:00:00Z")

        write_result(
            self.paths,
            request,
            {
                "exit_code": 0,
                "stdout": "[]",
                "stderr": "",
                "started_at": "2026-08-27T12:02:00Z",
                "finished_at": "2026-08-27T12:03:00Z",
            },
        )

        payload = json.loads(self.paths.last_result.read_text(encoding="utf-8"))
        self.assertEqual(payload["request"]["request_id"], "req-1")
        self.assertEqual(payload["execution"]["exit_code"], 0)
        self.assertEqual(
            stat.S_IMODE(self.paths.last_result.stat().st_mode), 0o600
        )

    def test_only_one_agent_process_lock_can_be_held(self) -> None:
        with acquire_agent_lock(self.paths) as first:
            with acquire_agent_lock(self.paths) as second:
                self.assertTrue(first)
                self.assertFalse(second)


if __name__ == "__main__":
    unittest.main()
