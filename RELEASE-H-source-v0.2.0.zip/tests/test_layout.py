import json
import subprocess
import unittest

from pathlib import Path

from release_h.layout import SCREEN_DISCOVERY_JXA, LayoutController
from release_h.models import ActionStatus
from release_h.pomodoro import FavoriteClickPlan
from release_h.runner import DryRunRunner


class StaticRunner:
    def __init__(self, screen_payload: list[dict[str, object]]) -> None:
        self.screen_payload = screen_payload
        self.calls: list[list[str]] = []

    def run(self, argv: list[str], timeout: float = 15) -> subprocess.CompletedProcess[str]:
        self.calls.append(argv)
        if "JavaScript" in argv:
            return subprocess.CompletedProcess(argv, 0, json.dumps(self.screen_payload), "")
        return subprocess.CompletedProcess(argv, 0, "", "")


class LayoutControllerTests(unittest.TestCase):
    def test_packaged_applescript_compiles(self) -> None:
        script_path = (
            Path(__file__).parents[1]
            / "src/release_h/applescript/layout.scpt"
        )
        result = subprocess.run(
            ["osacompile", "-o", "/tmp/release-h-layout-test.scpt", str(script_path)],
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(result.returncode, 0, result.stderr)

    def test_bilibili_ui_diagnostic_applescript_compiles(self) -> None:
        script_path = (
            Path(__file__).parents[1]
            / "scripts/diagnose-bilibili-ui.scpt"
        )
        result = subprocess.run(
            ["osacompile", "-o", "/tmp/release-h-bilibili-ui-test.scpt", str(script_path)],
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(result.returncode, 0, result.stderr)

    def test_packaged_applescript_restores_hidden_and_minimized_windows(self) -> None:
        script_path = (
            Path(__file__).parents[1]
            / "src/release_h/applescript/layout.scpt"
        )
        source = script_path.read_text(encoding="utf-8")

        self.assertIn("bundle identifier", source)
        self.assertIn("visible of targetProcess to true", source)
        self.assertIn('attribute "AXMinimized"', source)

    def test_screen_discovery_returns_json_even_without_gui_session(self) -> None:
        result = subprocess.run(
            ["osascript", "-l", "JavaScript", "-e", SCREEN_DISCOVERY_JXA],
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIsInstance(json.loads(result.stdout), list)

    def test_validation_requires_external_and_builtin_display(self) -> None:
        runner = StaticRunner(
            [
                {
                    "name": "External",
                    "is_main": True,
                    "is_builtin": False,
                    "visible": [0, 0, 2560, 1415],
                }
            ]
        )

        result = LayoutController(runner).validate_displays()

        self.assertEqual(result.status, ActionStatus.FAILED)
        self.assertIn("built-in", result.detail.lower())

    def test_builtin_may_be_main_while_external_hosts_work_space(self) -> None:
        runner = StaticRunner(
            [
                {
                    "name": "内建视网膜显示器",
                    "is_main": True,
                    "is_builtin": True,
                    "visible": [0, 39, 1710, 998],
                },
                {
                    "name": "DP",
                    "is_main": False,
                    "is_builtin": False,
                    "visible": [-626, -1692, 3008, 1692],
                },
            ]
        )
        controller = LayoutController(runner)

        validation = controller.validate_displays()
        self.assertEqual(validation.status, ActionStatus.COMPLETED)

        arranged = controller.arrange_work_space("Visual Studio Code", "Terminal")
        self.assertEqual(arranged.status, ActionStatus.COMPLETED)
        self.assertEqual(runner.calls[-1][-4:], ["-626", "-1692", "3008", "1692"])

    def test_work_space_uses_equal_halves_of_external_display(self) -> None:
        runner = DryRunRunner()
        controller = LayoutController(runner)
        self.assertEqual(controller.validate_displays().status, ActionStatus.COMPLETED)

        result = controller.arrange_work_space("Visual Studio Code", "Terminal")

        self.assertEqual(result.status, ActionStatus.COMPLETED)
        command = runner.calls[-1]
        self.assertIn("arrange-work-space", command)
        self.assertIn("Visual Studio Code", command)
        self.assertIn("Terminal", command)
        self.assertEqual(command[-4:], ["0", "0", "2560", "1415"])

    def test_fullscreen_command_targets_named_display_role(self) -> None:
        runner = DryRunRunner()
        controller = LayoutController(runner)
        controller.validate_displays()

        result = controller.fullscreen_on_display("claude", "Claude", "builtin")

        self.assertEqual(result.status, ActionStatus.COMPLETED)
        command = runner.calls[-1]
        self.assertIn("fullscreen", command)
        self.assertIn("Claude", command)
        self.assertEqual(command[-4:], ["-1512", "0", "1512", "982"])

    def test_pomodoro_opens_bilibili_app_on_builtin_display(self) -> None:
        runner = DryRunRunner()
        controller = LayoutController(runner, video_app_name="哔哩哔哩")
        controller.validate_displays()

        plan = FavoriteClickPlan("RELEASE H 番茄钟", page_downs=4, column=2)
        result = controller.open_pomodoro(plan)

        self.assertEqual(result.status, ActionStatus.COMPLETED)
        launch_command = runner.calls[-2]
        layout_command = runner.calls[-1]
        self.assertEqual(launch_command, ["open", "-a", "哔哩哔哩"])
        self.assertIn("open-favorite-pomodoro", layout_command)
        self.assertIn("哔哩哔哩", layout_command)
        self.assertIn("RELEASE H 番茄钟", layout_command)
        self.assertEqual(layout_command[-6:], ["4", "2", "-1512", "0", "1512", "982"])

    def test_web_pomodoro_opens_browser_on_builtin_display(self) -> None:
        runner = DryRunRunner()
        try:
            controller = LayoutController(
                runner, browser_app_name="Google Chrome"
            )
        except TypeError as error:
            self.fail(f"browser layout is not supported: {error}")
        controller.validate_displays()

        result = controller.open_web_pomodoro(
            "https://www.bilibili.com/video/BVWEB/"
        )

        self.assertEqual(result.status, ActionStatus.COMPLETED)
        launch_command = runner.calls[-2]
        layout_command = runner.calls[-1]
        self.assertEqual(
            launch_command,
            [
                "open",
                "-a",
                "Google Chrome",
                "https://www.bilibili.com/video/BVWEB/",
            ],
        )
        self.assertIn("open-web-pomodoro", layout_command)
        self.assertIn("Google Chrome", layout_command)
        self.assertIn("https://www.bilibili.com/video/BVWEB/", layout_command)
        self.assertEqual(
            layout_command[-7:],
            [
                "500",
                "430",
                "3",
                "-1512",
                "0",
                "1512",
                "982",
            ],
        )


if __name__ == "__main__":
    unittest.main()
