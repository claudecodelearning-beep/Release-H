import unittest

from release_h.devices import PendingDeviceAdapter
from release_h.models import ActionResult, ActionStatus
from release_h.pomodoro import FavoriteClickPlan, Video
from release_h.workflow import StartWorkWorkflow


def completed(action: str) -> ActionResult:
    return ActionResult(action, ActionStatus.COMPLETED, 0, "ok")


class FakeApps:
    def __init__(self, failing_key: str | None = None) -> None:
        self.failing_key = failing_key
        self.calls: list[tuple[str, str]] = []

    def ensure_open(self, key: str, app_name: str) -> ActionResult:
        self.calls.append((key, app_name))
        if key == self.failing_key:
            raise RuntimeError(f"{key} exploded")
        return completed(f"apps.{key}")


class FakePomodoro:
    def select(self) -> FavoriteClickPlan:
        return FavoriteClickPlan("RELEASE H 番茄钟", page_downs=4, column=2)


class FakeWebPomodoro:
    def select(self) -> Video:
        return Video("BVWEB", "网页番茄钟", "https://example.test/BVWEB")


class FakeLayout:
    def __init__(self, display_status: ActionStatus = ActionStatus.COMPLETED) -> None:
        self.display_status = display_status
        self.calls: list[tuple[object, ...]] = []

    def validate_displays(self) -> ActionResult:
        self.calls.append(("validate",))
        return ActionResult("layout.displays", self.display_status, 0, "display")

    def arrange_work_space(self, vscode: str, terminal: str) -> ActionResult:
        self.calls.append(("arrange", vscode, terminal))
        return completed("layout.work_space")

    def fullscreen_on_display(
        self, key: str, app_name: str, role: str
    ) -> ActionResult:
        self.calls.append(("fullscreen", key, app_name, role))
        return completed(f"layout.{key}")

    def open_pomodoro(self, plan: FavoriteClickPlan) -> ActionResult:
        self.calls.append(("pomodoro", plan))
        return completed("layout.pomodoro")

    def open_web_pomodoro(self, url: str) -> ActionResult:
        self.calls.append(("web-pomodoro", url))
        return completed("layout.pomodoro")


APP_NAMES = {
    "vscode": "Visual Studio Code",
    "terminal": "Terminal",
    "notes": "Notes",
    "codex": "Codex",
    "claude": "Claude",
}


class WorkflowTests(unittest.TestCase):
    def make_workflow(
        self,
        apps: FakeApps | None = None,
        layout: FakeLayout | None = None,
    ) -> StartWorkWorkflow:
        return StartWorkWorkflow(
            apps=apps or FakeApps(),
            pomodoro=FakePomodoro(),
            layout=layout or FakeLayout(),
            devices=PendingDeviceAdapter(),
            app_names=APP_NAMES,
            device_actions=("coffee", "air_conditioner", "standing_desk"),
        )

    def test_device_actions_are_pending(self) -> None:
        result = PendingDeviceAdapter().press("coffee")

        self.assertEqual(result.action, "device.coffee")
        self.assertEqual(result.status, ActionStatus.PENDING_HARDWARE)

    def test_exact_layout_targets_and_order(self) -> None:
        layout = FakeLayout()
        results = self.make_workflow(layout=layout).run()

        self.assertEqual(
            layout.calls,
            [
                ("validate",),
                ("fullscreen", "vscode", "Visual Studio Code", "external"),
                ("fullscreen", "terminal", "Terminal", "external"),
                ("fullscreen", "notes", "Notes", "external"),
                ("fullscreen", "codex", "Codex", "external"),
                (
                    "pomodoro",
                    FavoriteClickPlan("RELEASE H 番茄钟", page_downs=4, column=2),
                ),
                ("fullscreen", "claude", "Claude", "builtin"),
            ],
        )
        self.assertEqual(results[-3].status, ActionStatus.PENDING_HARDWARE)

    def test_one_failure_does_not_stop_later_actions(self) -> None:
        results = self.make_workflow(apps=FakeApps(failing_key="notes")).run()

        notes = next(result for result in results if result.action == "apps.notes")
        coffee = next(result for result in results if result.action == "device.coffee")
        self.assertEqual(notes.status, ActionStatus.FAILED)
        self.assertIn("exploded", notes.detail)
        self.assertEqual(coffee.status, ActionStatus.PENDING_HARDWARE)

    def test_web_mode_routes_selected_video_to_browser_layout(self) -> None:
        layout = FakeLayout()
        workflow = self.make_workflow(layout=layout)
        workflow.pomodoro = FakeWebPomodoro()
        workflow.pomodoro_mode = "web"

        workflow.run()

        self.assertIn(
            ("web-pomodoro", "https://example.test/BVWEB"), layout.calls
        )
        self.assertFalse(any(call[0] == "pomodoro" for call in layout.calls))

    def test_layout_is_skipped_when_required_displays_are_missing(self) -> None:
        layout = FakeLayout(display_status=ActionStatus.FAILED)
        results = self.make_workflow(layout=layout).run()

        self.assertEqual(layout.calls, [("validate",)])
        skipped = [result for result in results if result.status is ActionStatus.SKIPPED]
        self.assertEqual(len(skipped), 6)
        self.assertTrue(any(result.action == "layout.claude" for result in skipped))
        self.assertEqual(results[-1].status, ActionStatus.PENDING_HARDWARE)


if __name__ == "__main__":
    unittest.main()
