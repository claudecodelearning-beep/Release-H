import tempfile
import unittest
from pathlib import Path

from release_h.config import default_config
from release_h.models import ActionResult, ActionStatus


class ActionResultTests(unittest.TestCase):
    def test_serializes_status_as_stable_string(self) -> None:
        result = ActionResult("apps.codex", ActionStatus.COMPLETED, 12, "ready")

        self.assertEqual(
            result.to_dict(),
            {
                "action": "apps.codex",
                "status": "completed",
                "elapsed_ms": 12,
                "detail": "ready",
            },
        )


class WorkflowConfigTests(unittest.TestCase):
    def test_default_config_contains_creator_and_device_actions(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = default_config(Path(directory))

        self.assertEqual(config.bilibili_mid, 487014659)
        self.assertEqual(
            config.device_actions,
            ("coffee", "air_conditioner", "standing_desk"),
        )
        self.assertEqual(config.video_app_name, "哔哩哔哩")


if __name__ == "__main__":
    unittest.main()
