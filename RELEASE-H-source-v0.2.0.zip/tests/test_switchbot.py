import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock

from release_h.agent import Agent, ExecutionResult
from release_h.agent_queue import QueuePaths, enqueue_start, recover_interrupted
from release_h.models import ActionStatus
from release_h.switchbot import SwitchBotAdapter, bind_bot, load_bindings

BOT = "12345678-1234-5678-1234-567812345648"


class SwitchBotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.transport = Mock(return_value={"status": "completed", "detail": "ack"})
        bind_bot(self.root, "air_conditioner", BOT)

    def adapter(self, **kwargs):
        return SwitchBotAdapter(self.root, transport=self.transport, **kwargs)

    def test_unconfigured_coffee_never_touches_bluetooth(self):
        self.assertEqual(self.adapter().press("coffee").status, ActionStatus.PENDING_HARDWARE)
        self.transport.assert_not_called()

    def test_dry_run_never_touches_bluetooth_or_consumes_request(self):
        self.assertEqual(self.adapter(dry_run=True, request_id="one").press("air_conditioner").status,
                         ActionStatus.SKIPPED)
        self.transport.assert_not_called()
        self.assertFalse((self.root / "bot-attempts").exists())

    def test_same_request_not_repeated_across_adapter_restart(self):
        for _ in range(3):
            result = self.adapter(request_id="one").press("air_conditioner")
            self.assertEqual(result.status, ActionStatus.COMPLETED)
        self.transport.assert_called_once_with("press", BOT)
        self.adapter(request_id="two").press("air_conditioner")
        self.assertEqual(self.transport.call_count, 2)

    def test_uncertain_failure_not_retried(self):
        self.transport.side_effect = TimeoutError("ack lost")
        for _ in range(2):
            self.assertEqual(self.adapter(request_id="one").press("air_conditioner").status,
                             ActionStatus.FAILED)
        self.transport.assert_called_once()

    def test_corrupt_journal_blocks_replay(self):
        self.adapter(request_id="one").press("air_conditioner")
        path = next((self.root / "bot-attempts").glob("*/*.json"))
        path.write_text("")
        self.assertEqual(self.adapter(request_id="one").press("air_conditioner").status,
                         ActionStatus.FAILED)
        self.transport.assert_called_once()

    def test_duplicate_role_binding_rejected(self):
        with self.assertRaises(ValueError):
            bind_bot(self.root, "coffee", BOT)
        self.assertEqual(load_bindings(self.root), {"air_conditioner": BOT})

    def test_invalid_id_rejected_without_overwriting_binding(self):
        with self.assertRaises(ValueError):
            bind_bot(self.root, "air_conditioner", "Bot48")
        self.assertEqual(load_bindings(self.root)["air_conditioner"], BOT)

    def test_app_mac_address_can_be_used_without_mac_scan(self):
        bind_bot(self.root, "air_conditioner", "AA-BB-CC-DD-EE-48")
        self.adapter().press("air_conditioner")
        self.transport.assert_called_once_with("press", "AA:BB:CC:DD:EE:48")

    def test_malformed_config_returns_failure_without_hardware_action(self):
        (self.root / "switchbot.json").write_text('{"air_conditioner":null}')
        self.assertEqual(self.adapter().press("air_conditioner").status, ActionStatus.FAILED)
        self.transport.assert_not_called()

    def test_locked_then_restart_then_unlock_presses_once_and_runs_desktop(self):
        paths = QueuePaths.at(self.root)
        enqueue_start(paths, "one")
        desktop = Mock(return_value=ExecutionResult(0, "[]", "", "start", "finish"))
        def hardware(request_id):
            return [self.adapter(request_id=request_id).press("air_conditioner").to_dict()]
        agent = Agent(paths, lambda: False, desktop, hardware)
        self.assertEqual(agent.run_once().status, "locked")
        agent.run_once()
        desktop.assert_not_called()
        self.transport.assert_called_once()
        Agent(paths, lambda: True, desktop, hardware).run_once()
        self.transport.assert_called_once()
        desktop.assert_called_once()
        saved = json.loads(paths.last_result.read_text())
        self.assertEqual(saved["execution"]["hardware"][0]["status"], "completed")

    def test_hardware_failure_does_not_block_desktop_but_reports_failure(self):
        paths = QueuePaths.at(self.root)
        enqueue_start(paths, "one")
        self.transport.side_effect = RuntimeError("Bluetooth off")
        desktop = Mock(return_value=ExecutionResult(0, "[]", "", "start", "finish"))
        def hardware(request_id):
            return [self.adapter(request_id=request_id).press("air_conditioner").to_dict()]
        self.assertEqual(Agent(paths, lambda: True, desktop, hardware).run_once().status, "failed")
        desktop.assert_called_once()

    def test_recovered_running_request_does_not_repeat_press(self):
        paths = QueuePaths.at(self.root)
        enqueue_start(paths, "one")
        self.adapter(request_id="one").press("air_conditioner")
        paths.pending.rename(paths.running)
        recover_interrupted(paths)
        self.adapter(request_id="one").press("air_conditioner")
        self.transport.assert_called_once()

    def test_malformed_request_never_reaches_hardware(self):
        paths = QueuePaths.at(self.root)
        paths.pending.write_text('{"action":"arbitrary"}')
        hardware = Mock()
        Agent(paths, lambda: False, execute_hardware=hardware).run_once()
        hardware.assert_not_called()


if __name__ == "__main__":
    unittest.main()
