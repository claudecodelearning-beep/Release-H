import contextlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from release_h.agent_queue import QueuePaths, enqueue_start
from release_h.cli import main
from release_h.models import ActionResult, ActionStatus


class FakeWorkflow:
    def __init__(self, results: list[ActionResult]) -> None:
        self.results = results

    def run(self) -> list[ActionResult]:
        return self.results


class CliTests(unittest.TestCase):
    def test_request_start_queues_without_building_workflow(self) -> None:
        stdout = io.StringIO()
        with tempfile.TemporaryDirectory() as temporary:
            with patch.dict(
                os.environ, {"RELEASE_H_RUNTIME_DIR": temporary}, clear=False
            ):
                with patch("release_h.cli.build_workflow") as build_workflow:
                    with contextlib.redirect_stdout(stdout):
                        exit_code = main(["request-start", "--json"])

            payload = json.loads(stdout.getvalue())
            request = json.loads(
                (Path(temporary) / "pending-start-work.json").read_text(
                    encoding="utf-8"
                )
            )

        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["status"], "queued")
        self.assertEqual(request["action"], "start-work")
        build_workflow.assert_not_called()

    def test_agent_once_reports_locked_without_consuming_request(self) -> None:
        stdout = io.StringIO()
        with tempfile.TemporaryDirectory() as temporary:
            paths = QueuePaths.at(Path(temporary))
            enqueue_start(paths, "req-1")
            with patch.dict(
                os.environ, {"RELEASE_H_RUNTIME_DIR": temporary}, clear=False
            ):
                with patch(
                    "release_h.cli.mac_session_unlocked", return_value=False
                ):
                    with contextlib.redirect_stdout(stdout):
                        exit_code = main(["agent", "--once", "--json"])

            payload = json.loads(stdout.getvalue())
            pending_still_exists = paths.pending.exists()

        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["status"], "locked")
        self.assertTrue(pending_still_exists)

    def test_default_pomodoro_mode_uses_web_video(self) -> None:
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            exit_code = main(["start-work", "--dry-run", "--json"])

        payload = json.loads(stdout.getvalue())
        selection = next(
            item for item in payload if item["action"] == "pomodoro.select"
        )
        self.assertEqual(exit_code, 0)
        self.assertIn("https://", selection["detail"])

    def test_dry_run_json_contains_complete_workflow(self) -> None:
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            exit_code = main(["start-work", "--dry-run", "--json"])

        payload = json.loads(stdout.getvalue())
        actions = {item["action"] for item in payload}
        self.assertEqual(exit_code, 0)
        self.assertTrue(
            {
                "apps.vscode",
                "apps.terminal",
                "apps.notes",
                "apps.codex",
                "apps.claude",
                "pomodoro.select",
                "layout.vscode",
                "layout.terminal",
                "layout.notes",
                "layout.codex",
                "layout.pomodoro",
                "layout.claude",
                "device.coffee",
                "device.air_conditioner",
                "device.standing_desk",
            }.issubset(actions)
        )

    def test_required_display_failure_returns_one(self) -> None:
        workflow = FakeWorkflow(
            [
                ActionResult(
                    "layout.displays", ActionStatus.FAILED, 1, "missing display"
                ),
                ActionResult(
                    "device.coffee", ActionStatus.PENDING_HARDWARE, 0, "later"
                ),
            ]
        )
        stdout = io.StringIO()
        with patch("release_h.cli.build_workflow", return_value=workflow):
            with contextlib.redirect_stdout(stdout):
                exit_code = main(["start-work"])

        self.assertEqual(exit_code, 1)
        self.assertIn("layout.displays", stdout.getvalue())
        self.assertIn("device.coffee", stdout.getvalue())

    def test_web_pomodoro_mode_can_be_selected_from_command_line(self) -> None:
        stdout = io.StringIO()
        try:
            with contextlib.redirect_stdout(stdout):
                exit_code = main(
                    [
                        "start-work",
                        "--dry-run",
                        "--pomodoro-mode",
                        "web",
                        "--json",
                    ]
                )
        except SystemExit as error:
            self.fail(f"web pomodoro mode was rejected: {error}")

        payload = json.loads(stdout.getvalue())
        selection = next(
            item for item in payload if item["action"] == "pomodoro.select"
        )
        self.assertEqual(exit_code, 0)
        self.assertIn("https://", selection["detail"])

    def test_pending_hardware_does_not_fail_command(self) -> None:
        workflow = FakeWorkflow(
            [
                ActionResult(
                    "layout.displays", ActionStatus.COMPLETED, 1, "ready"
                ),
                ActionResult(
                    "device.coffee", ActionStatus.PENDING_HARDWARE, 0, "later"
                ),
            ]
        )
        with patch("release_h.cli.build_workflow", return_value=workflow):
            with contextlib.redirect_stdout(io.StringIO()):
                exit_code = main(["start-work"])

        self.assertEqual(exit_code, 0)


if __name__ == "__main__":
    unittest.main()
