import subprocess
import unittest

from release_h.apps import ApplicationController
from release_h.models import ActionStatus


class FakeRunner:
    def __init__(self, results: list[subprocess.CompletedProcess[str]]) -> None:
        self.results = list(results)
        self.calls: list[list[str]] = []

    def run(self, argv: list[str], timeout: float = 15) -> subprocess.CompletedProcess[str]:
        self.calls.append(argv)
        if not self.results:
            raise AssertionError(f"Unexpected command: {argv}")
        return self.results.pop(0)


def completed(
    returncode: int = 0, stdout: str = "", stderr: str = ""
) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess([], returncode, stdout, stderr)


class ApplicationControllerTests(unittest.TestCase):
    def test_running_application_is_reused_without_opening_duplicate(self) -> None:
        runner = FakeRunner([completed(stdout="true\n")])

        result = ApplicationController(runner).ensure_open("codex", "Codex")

        self.assertEqual(result.status, ActionStatus.ALREADY_RUNNING)
        self.assertEqual(len(runner.calls), 1)
        self.assertEqual(runner.calls[0][0], "osascript")

    def test_missing_application_is_opened(self) -> None:
        runner = FakeRunner([completed(stdout="false\n"), completed()])

        result = ApplicationController(runner).ensure_open("notes", "Notes")

        self.assertEqual(result.status, ActionStatus.OPENED)
        self.assertEqual(runner.calls[1], ["open", "-a", "Notes"])

    def test_launch_failure_is_reported_without_exception(self) -> None:
        runner = FakeRunner(
            [completed(stdout="false\n"), completed(returncode=1, stderr="not found")]
        )

        result = ApplicationController(runner).ensure_open("claude", "Claude")

        self.assertEqual(result.status, ActionStatus.FAILED)
        self.assertIn("not found", result.detail)

    def test_status_probe_failure_is_reported(self) -> None:
        runner = FakeRunner([completed(returncode=1, stderr="automation denied")])

        result = ApplicationController(runner).ensure_open("vscode", "Visual Studio Code")

        self.assertEqual(result.status, ActionStatus.FAILED)
        self.assertIn("automation denied", result.detail)


if __name__ == "__main__":
    unittest.main()
