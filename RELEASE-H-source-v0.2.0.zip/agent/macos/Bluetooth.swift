import CoreBluetooth
import Foundation

// Protocol: github.com/OpenWonderLabs/SwitchBotAPI-BLE/devicetypes/bot.md
final class BotBluetooth: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    private var central: CBCentralManager!
    private var peripheral: CBPeripheral?
    private var writer: CBCharacteristic?
    private var devices: [String: [String: Any]] = [:]
    private var finished = false
    private var sent = false
    private let operation: String
    private let target: String?
    private let service = CBUUID(string: "cba20d00-224d-11e6-9fb8-0002a5d5c51b")
    private let writeID = CBUUID(string: "cba20002-224d-11e6-9fb8-0002a5d5c51b")
    private let notifyID = CBUUID(string: "cba20003-224d-11e6-9fb8-0002a5d5c51b")

    init(operation: String, target: String?) {
        self.operation = operation
        self.target = target
        super.init()
    }

    func start() {
        central = CBCentralManager(delegate: self, queue: .main)
        DispatchQueue.main.asyncAfter(deadline: .now() + 25) { [self] in
            fail(sent ? "No Bot acknowledgement; press outcome unknown, do not retry blindly"
                      : "Bluetooth timed out; check permission, power and proximity")
        }
    }

    private func finish(_ payload: [String: Any], code: Int32 = 0) {
        guard !finished else { return }
        finished = true
        central?.stopScan()
        if let peripheral { central?.cancelPeripheralConnection(peripheral) }
        let data = try! JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys])
        print(String(data: data, encoding: .utf8)!)
        fflush(stdout)
        exit(code)
    }

    private func fail(_ detail: String) {
        finish(["status": "failed", "detail": detail], code: 1)
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            central.scanForPeripherals(withServices: nil,
                options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
            DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [self] in
                guard !finished, peripheral == nil else { return }
                if operation == "scan" {
                    finish(["status": "completed", "devices": devices.values.sorted {
                        ($0["id"] as! String) < ($1["id"] as! String)
                    }])
                } else {
                    fail("Configured Bot not found; keep it nearby and close its phone control screen")
                }
            }
        case .unauthorized:
            fail("Allow RELEASE H Agent Bluetooth access in macOS Privacy & Security > Bluetooth")
        case .poweredOff: fail("Mac Bluetooth is off")
        case .unsupported: fail("Bluetooth LE is unavailable")
        default: break
        }
    }

    func centralManager(_ central: CBCentralManager, didDiscover bot: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        guard peripheral == nil,
              let services = advertisementData[CBAdvertisementDataServiceDataKey] as? [CBUUID: Data],
              let data = services.first(where: {
                  ["FD3D", "000D"].contains($0.key.uuidString.uppercased())
              })?.value else { return }
        let bytes = [UInt8](data)
        guard bytes.count >= 3, bytes[0] & 0x7f == 0x48 else { return }
        let encrypted = bytes[0] & 0x80 != 0 || bytes[1] & 0x20 != 0
        let switchMode = bytes[1] & 0x80 != 0
        var item: [String: Any] = [
            "id": bot.identifier.uuidString.lowercased(),
            "name": advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? bot.name ?? "SwitchBot Bot",
            "battery": Int(bytes[2] & 0x7f), "rssi": RSSI,
            "mode": switchMode ? "switch" : "press", "encrypted": encrypted
        ]
        if let manufacturer = advertisementData[CBAdvertisementDataManufacturerDataKey] as? Data {
            let m = [UInt8](manufacturer)
            if m.count >= 8 && ((m[0] == 0x69 && m[1] == 0x09) || (m[0] == 0x59 && m[1] == 0)) {
                item["mac"] = m[2..<8].map { String(format: "%02X", $0) }.joined(separator: ":")
            }
        }
        devices[bot.identifier.uuidString] = item
        guard operation == "press", let target,
              bot.identifier.uuidString.lowercased() == target.lowercased() ||
              (item["mac"] as? String) == target.uppercased() else { return }
        guard !encrypted else { fail("Password-protected Bot requires an authenticated adapter; no command sent"); return }
        guard !switchMode else { fail("Set this Bot to Press mode in SwitchBot App first"); return }
        peripheral = bot
        central.stopScan()
        bot.delegate = self
        central.connect(bot)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.discoverServices([service])
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        fail(error?.localizedDescription ?? "Bot connection failed")
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        fail(sent ? "Disconnected before acknowledgement; press outcome unknown" : "Bot disconnected")
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard error == nil, let found = peripheral.services?.first(where: { $0.uuid == service }) else {
            fail("SwitchBot control service unavailable"); return
        }
        peripheral.discoverCharacteristics([writeID, notifyID], for: found)
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil,
              let write = service.characteristics?.first(where: { $0.uuid == writeID }),
              let notify = service.characteristics?.first(where: { $0.uuid == notifyID }) else {
            fail("SwitchBot control characteristics unavailable"); return
        }
        writer = write
        peripheral.setNotifyValue(true, for: notify)
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil, characteristic.isNotifying, let writer else {
            fail("Unable to subscribe to Bot acknowledgements"); return
        }
        guard !sent else { return }
        let type: CBCharacteristicWriteType
        if writer.properties.contains(.write) { type = .withResponse }
        else if writer.properties.contains(.writeWithoutResponse) { type = .withoutResponse }
        else { fail("Bot characteristic is not writable"); return }
        sent = true
        peripheral.writeValue(Data([0x57, 0x01, 0x00]), for: writer, type: type)
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error { fail("Write failed: \(error.localizedDescription); press outcome may be unknown") }
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard sent, characteristic.uuid == notifyID else { return }
        guard error == nil, let status = characteristic.value?.first else {
            fail("Invalid Bot acknowledgement; press outcome unknown"); return
        }
        if status == 1 {
            finish(["status": "completed", "detail": "Bot acknowledged one press", "id": peripheral.identifier.uuidString.lowercased()])
        } else {
            fail(String(format: "Bot rejected press (status 0x%02X); check mode, battery or password", status))
        }
    }
}

func runBluetoothCommand(_ args: [String]) -> Never {
    let operation = args.count > 2 ? args[2] : ""
    let target = args.count > 3 ? args[3] : nil
    let validTarget = target.map {
        UUID(uuidString: $0) != nil ||
        $0.range(of: "^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$", options: .regularExpression) != nil
    } ?? false
    guard (operation == "scan" && args.count == 3) ||
          (operation == "press" && args.count == 4 && validTarget) else {
        print("{\"status\":\"failed\",\"detail\":\"Usage: --ble scan | --ble press UUID-or-MAC\"}")
        exit(2)
    }
    let controller = BotBluetooth(operation: operation, target: target)
    controller.start()
    withExtendedLifetime(controller) { RunLoop.main.run() }
    exit(1)
}
