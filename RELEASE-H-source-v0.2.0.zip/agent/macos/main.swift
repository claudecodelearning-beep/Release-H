import AppKit
import ApplicationServices
import Foundation

if CommandLine.arguments.dropFirst().first == "--ble" {
    runBluetoothCommand(CommandLine.arguments)
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var child: Process?
    private var stopping = false

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApplication.shared.setActivationPolicy(.accessory)
        let prompt = [
            kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true
        ] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(prompt)
        startAgent()
    }

    func applicationWillTerminate(_ notification: Notification) {
        stopping = true
        if let child, child.isRunning {
            child.terminate()
        }
    }

    private func startAgent() {
        guard !stopping else { return }
        guard let projectPath = Bundle.main.object(
            forInfoDictionaryKey: "ReleaseHProjectPath"
        ) as? String else {
            fputs("RELEASE H Agent: missing ReleaseHProjectPath\n", stderr)
            NSApplication.shared.terminate(nil)
            return
        }

        let projectURL = URL(fileURLWithPath: projectPath, isDirectory: true)
        let pythonURL = projectURL.appendingPathComponent(".venv/bin/python")
        guard FileManager.default.isExecutableFile(atPath: pythonURL.path) else {
            fputs("RELEASE H Agent: run scripts/install-local.sh first\n", stderr)
            NSApplication.shared.terminate(nil)
            return
        }

        let process = Process()
        process.executableURL = pythonURL
        process.arguments = ["-m", "release_h.cli", "agent"]
        process.currentDirectoryURL = projectURL

        var environment = ProcessInfo.processInfo.environment
        let sourcePath = projectURL.appendingPathComponent("src").path
        if let existing = environment["PYTHONPATH"], !existing.isEmpty {
            environment["PYTHONPATH"] = sourcePath + ":" + existing
        } else {
            environment["PYTHONPATH"] = sourcePath
        }
        environment["RELEASE_H_RUNTIME_DIR"] = projectURL
            .appendingPathComponent("runtime", isDirectory: true).path
        process.environment = environment

        process.terminationHandler = { [weak self] _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                guard let self, !self.stopping else { return }
                self.child = nil
                self.startAgent()
            }
        }

        do {
            try process.run()
            child = process
        } catch {
            fputs("RELEASE H Agent: \(error)\n", stderr)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
                self?.startAgent()
            }
        }
    }
}

let application = NSApplication.shared
let delegate = AppDelegate()
application.delegate = delegate
application.run()
