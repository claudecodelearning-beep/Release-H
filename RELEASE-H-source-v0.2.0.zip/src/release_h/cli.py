from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from pathlib import Path
from typing import Sequence

from .agent import Agent, append_log, mac_session_unlocked, run_forever
from .agent_queue import (
    QueuePaths,
    acquire_agent_lock,
    default_runtime_dir,
    enqueue_start,
    recover_interrupted,
)
from .apps import ApplicationController
from .config import default_config
from .switchbot import ROLES, SwitchBotAdapter, bind_bot, invoke_ble, load_bindings, run_hardware
from .layout import LayoutController
from .models import ActionResult, ActionStatus
from .pomodoro import FavoriteFolderSelector, PomodoroRepository, fetch_creator_videos
from .runner import DryRunRunner, SubprocessRunner
from .workflow import StartWorkWorkflow


def build_workflow(
    dry_run: bool = False,
    state_dir: Path | None = None,
    pomodoro_mode: str = "web",
    skip_devices: bool = False,
) -> StartWorkWorkflow:
    config = default_config(state_dir)
    runner = DryRunRunner() if dry_run else SubprocessRunner()
    if pomodoro_mode == "web":
        fallback_path = Path(__file__).parent / "data/fallback_videos.json"

        if dry_run:
            def fetcher():
                raise OSError("network disabled during dry run")
        else:
            def fetcher():
                return fetch_creator_videos(config.bilibili_mid)

        pomodoro = PomodoroRepository(
            config.state_dir, fetcher, fallback_path
        )
    else:
        pomodoro = FavoriteFolderSelector(
            folder_name=config.favorite_folder_name,
            state_dir=config.state_dir,
            max_page_downs=config.favorite_max_page_downs,
            columns=config.favorite_columns,
            search_text=config.favorite_search_text,
        )

    return StartWorkWorkflow(
        apps=ApplicationController(runner),
        pomodoro=pomodoro,
        layout=LayoutController(
            runner,
            video_app_name=config.video_app_name,
            browser_app_name=config.browser_app_name,
        ),
        devices=SwitchBotAdapter(dry_run=dry_run),
        app_names=config.app_names,
        device_actions=() if skip_devices else config.device_actions,
        pomodoro_mode=pomodoro_mode,
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="release-h", description="一键进入 RELEASE H 工作模式"
    )
    subcommands = parser.add_subparsers(dest="command", required=True)
    start = subcommands.add_parser("start-work", help="打开并排列工作环境")
    start.add_argument(
        "--dry-run", action="store_true", help="仅模拟，不操作桌面或联网"
    )
    start.add_argument("--json", action="store_true", help="输出 JSON 结果")
    start.add_argument("--skip-devices", action="store_true", help="仅执行桌面部分（Agent 已执行硬件时使用）")
    start.add_argument(
        "--pomodoro-mode",
        choices=("app", "web"),
        default="web",
        help="番茄钟打开方式：哔哩哔哩 App 收藏夹或网页",
    )

    request = subcommands.add_parser(
        "request-start", help="为本地 RELEASE H Agent 排队一次工作流"
    )
    request.add_argument("--json", action="store_true", help="输出 JSON 结果")

    agent = subcommands.add_parser(
        "agent", help="运行锁屏感知的 RELEASE H 本地 Agent"
    )
    agent.add_argument(
        "--once", action="store_true", help="只检查并处理一次队列"
    )
    agent.add_argument(
        "--poll-seconds",
        type=float,
        default=2.0,
        help="队列轮询间隔，默认 2 秒",
    )
    agent.add_argument("--json", action="store_true", help="输出 JSON 结果")

    bot = subcommands.add_parser("bot", help="本地蓝牙 SwitchBot 设置和测试")
    operations = bot.add_subparsers(dest="bot_command", required=True)
    for name in ("scan", "status"):
        operations.add_parser(name).add_argument("--json", action="store_true")
    bind = operations.add_parser("bind")
    bind.add_argument("role", choices=ROLES)
    bind.add_argument("identifier", help="scan 返回的蓝牙 UUID 或 SwitchBot App 显示的 MAC 地址")
    bind.add_argument("--json", action="store_true")
    press = operations.add_parser("press", help="立即按一次已绑定 Bot")
    press.add_argument("role", choices=ROLES)
    press.add_argument("--json", action="store_true")
    return parser


def _print_human(results: Sequence[ActionResult]) -> None:
    for result in results:
        print(
            f"[{result.status.value:>16}] {result.action} "
            f"({result.elapsed_ms} ms) — {result.detail}"
        )


def _exit_code(results: Sequence[ActionResult]) -> int:
    return 1 if any(
        (result.action == "layout.displays" or result.action.startswith("device."))
        and result.status is ActionStatus.FAILED
        for result in results
    ) else 0


def _print_status(payload: dict[str, object], json_output: bool) -> None:
    if json_output:
        print(json.dumps(payload, ensure_ascii=False))
    else:
        print(f"[{payload['status']}] {payload.get('detail', '')}".rstrip())


def _request_start(json_output: bool) -> int:
    paths = QueuePaths.at(default_runtime_dir())
    try:
        request = enqueue_start(paths)
    except PermissionError as error:
        _print_status(
            {"status": "unavailable", "detail": str(error)}, json_output
        )
        return 1
    except OSError as error:
        _print_status({"status": "error", "detail": str(error)}, json_output)
        return 1
    _print_status({"status": "queued", **request.to_dict()}, json_output)
    return 0


def _run_agent(args: argparse.Namespace) -> int:
    if args.poll_seconds <= 0:
        _print_status(
            {"status": "error", "detail": "poll-seconds must be positive"},
            args.json,
        )
        return 2

    paths = QueuePaths.at(default_runtime_dir())
    with acquire_agent_lock(paths) as acquired:
        if not acquired:
            _print_status(
                {
                    "status": "already_running",
                    "detail": "Another RELEASE H Agent owns the queue",
                },
                args.json,
            )
            return 0

        recovered = recover_interrupted(paths)
        if recovered:
            append_log(paths, "recovered", "Recovered an interrupted request")
        agent = Agent(paths, session_unlocked=mac_session_unlocked,
                      execute_hardware=lambda request_id: run_hardware(request_id, paths.root))
        if args.once:
            outcome = agent.run_once()
            _print_status(outcome.to_dict(), args.json)
            return 1 if outcome.status in {"invalid", "failed"} else 0

        append_log(paths, "started", "RELEASE H Agent started")
        try:
            run_forever(agent, args.poll_seconds)
        except KeyboardInterrupt:
            append_log(paths, "stopped", "RELEASE H Agent stopped")
        return 0


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)

    if args.command == "request-start":
        return _request_start(args.json)
    if args.command == "agent":
        return _run_agent(args)
    if args.command == "bot":
        root = default_runtime_dir()
        try:
            if args.bot_command == "scan":
                payload = invoke_ble("scan")
            elif args.bot_command == "status":
                payload = {"status": "completed", "bindings": load_bindings(root)}
            elif args.bot_command == "bind":
                bind_bot(root, args.role, args.identifier)
                payload = {"status": "completed", "bindings": load_bindings(root)}
            else:
                result = SwitchBotAdapter(root).press(args.role)
                payload = result.to_dict()
            print(json.dumps(payload, ensure_ascii=False, indent=None if args.json else 2))
            return 0 if payload["status"] == "completed" else 1
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
            _print_status({"status": "failed", "detail": str(error)}, args.json)
            return 1

    if args.dry_run:
        with tempfile.TemporaryDirectory(prefix="release-h-dry-run-") as temporary:
            results = build_workflow(
                True, Path(temporary), args.pomodoro_mode, args.skip_devices
            ).run()
    else:
        results = build_workflow(
            False, pomodoro_mode=args.pomodoro_mode, skip_devices=args.skip_devices
        ).run()

    if args.json:
        print(json.dumps([result.to_dict() for result in results], ensure_ascii=False))
    else:
        _print_human(results)
    return _exit_code(results)


if __name__ == "__main__":
    raise SystemExit(main())
