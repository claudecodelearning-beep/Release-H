from dataclasses import asdict, dataclass
from enum import Enum


class ActionStatus(str, Enum):
    OPENED = "opened"
    ALREADY_RUNNING = "already_running"
    COMPLETED = "completed"
    PENDING_HARDWARE = "pending_hardware"
    SKIPPED = "skipped"
    FAILED = "failed"


@dataclass(frozen=True)
class ActionResult:
    action: str
    status: ActionStatus
    elapsed_ms: int
    detail: str

    def to_dict(self) -> dict[str, str | int]:
        data = asdict(self)
        data["status"] = self.status.value
        return data
