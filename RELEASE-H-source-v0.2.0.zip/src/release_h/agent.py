from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Callable

from .agent_queue import (
    InvalidRequest,
    QueuePaths,
    claim_request,
    load_request,
    write_result,
)


@dataclass(frozen=True)
class ExecutionResult:
    exit_code: int
    stdout: str
    stderr: str
    started_at: str
    finished_at: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class CycleResult:
    status: str
    detail: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def mac_session_unlocked(
    run: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> bool | None:
    try:
        response = run(
            ["/usr/sbin/ioreg", "-n", "Root", "-d", "1", "-w", "0"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if response.returncode != 0:
        return None
    output = response.stdout
    if (
        '"kCGSSessionOnConsoleKey"=Yes' not in output
        or '"kCGSessionLoginDoneKey"=Yes' not in output
    ):
        return None
    if '"CGSSessionScreenIsLocked"=Yes' in output:
        return False
    if '"CGSSessionScreenIsLocked"=No' in output:
        return True
    return True


def execute_start_work() -> ExecutionResult:
    started_at = _now()
    try:
        response = subprocess.run(
            [
                sys.executable,
                "-m",
                "release_h.cli",
                "start-work",
                "--json",
                "--skip-devices",
            ],
            capture_output=True,
            text=True,
            timeout=240,
            check=False,
        )
        return ExecutionResult(
            response.returncode,
            response.stdout,
            response.stderr,
            started_at,
            _now(),
        )
    except (OSError, subprocess.SubprocessError) as error:
        return ExecutionResult(1, "", str(error), started_at, _now())


def append_log(paths: QueuePaths, status: str, detail: str) -> None:
    paths.root.mkdir(parents=True, exist_ok=True, mode=0o700)
    line = json.dumps(
        {"timestamp": _now(), "status": status, "detail": detail},
        ensure_ascii=False,
        separators=(",", ":"),
    )
    descriptor = os.open(paths.log, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    with os.fdopen(descriptor, "a", encoding="utf-8") as stream:
        stream.write(line + "\n")
    paths.log.chmod(0o600)


class Agent:
    def __init__(
        self,
        paths: QueuePaths,
        session_unlocked: Callable[[], bool | None] = mac_session_unlocked,
        execute_workflow: Callable[[], ExecutionResult] = execute_start_work,
        execute_hardware: Callable[[str], list[dict]] | None = None,
    ) -> None:
        self.paths = paths
        self.session_unlocked = session_unlocked
        self.execute_workflow = execute_workflow
        self.execute_hardware = execute_hardware
        self._last_logged_status: str | None = None

    def _log_transition(self, status: str, detail: str) -> None:
        if status == self._last_logged_status:
            return
        append_log(self.paths, status, detail)
        self._last_logged_status = status

    def run_once(self) -> CycleResult:
        if not self.paths.pending.exists():
            return CycleResult("idle", "No pending request")

        hardware = []
        pending_id = None
        if self.execute_hardware is not None:
            try:
                pending_id = load_request(self.paths.pending).request_id
                hardware = self.execute_hardware(pending_id)
            except InvalidRequest:
                # Invalid queue entries must never reach the physical adapter.
                pass
            except Exception as error:
                hardware = [{"action": "devices", "status": "failed", "detail": str(error)}]

        unlocked = self.session_unlocked()
        if unlocked is not True:
            detail = (
                "Session is locked; request retained until unlock"
                if unlocked is False
                else "Session state is unknown; request retained until unlock"
            )
            self._log_transition("locked", detail)
            return CycleResult("locked", detail)

        try:
            request = claim_request(self.paths)
        except InvalidRequest as error:
            detail = str(error)
            self._log_transition("invalid", detail)
            return CycleResult("invalid", detail)
        if request is None:
            return CycleResult("idle", "Request was claimed elsewhere")

        try:
            if self.execute_hardware is not None and request.request_id != pending_id:
                hardware = self.execute_hardware(request.request_id)
            execution = self.execute_workflow()
        except Exception as error:  # Keep the persistent agent alive.
            execution = ExecutionResult(1, "", str(error), _now(), _now())

        payload = execution.to_dict()
        payload["hardware"] = hardware
        if any(item.get("status") == "failed" for item in hardware):
            payload["exit_code"] = 1
        write_result(self.paths, request, payload)
        self.paths.running.unlink(missing_ok=True)
        status = "completed" if payload["exit_code"] == 0 else "failed"
        detail = f"Workflow exited with code {payload['exit_code']}"
        self._log_transition(status, detail)
        return CycleResult(status, detail)


def run_forever(agent: Agent, poll_seconds: float = 2.0) -> None:
    while True:
        agent.run_once()
        time.sleep(poll_seconds)
