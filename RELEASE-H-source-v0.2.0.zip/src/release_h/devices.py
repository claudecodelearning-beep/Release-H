from __future__ import annotations

from typing import Protocol

from .models import ActionResult, ActionStatus


class DeviceAdapter(Protocol):
    def press(self, name: str) -> ActionResult: ...


class PendingDeviceAdapter:
    """Placeholder until the SwitchBot hardware integration is enabled."""

    def press(self, name: str) -> ActionResult:
        return ActionResult(
            action=f"device.{name}",
            status=ActionStatus.PENDING_HARDWARE,
            elapsed_ms=0,
            detail="SwitchBot hardware integration is not enabled yet",
        )
