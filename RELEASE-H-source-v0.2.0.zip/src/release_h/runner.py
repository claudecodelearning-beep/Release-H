import subprocess
import json
from typing import Protocol


class CommandRunner(Protocol):
    def run(
        self, argv: list[str], timeout: float = 15
    ) -> subprocess.CompletedProcess[str]: ...


class SubprocessRunner:
    def run(
        self, argv: list[str], timeout: float = 15
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )


class DryRunRunner:
    def __init__(self) -> None:
        self.calls: list[list[str]] = []

    def run(
        self, argv: list[str], timeout: float = 15
    ) -> subprocess.CompletedProcess[str]:
        self.calls.append(list(argv))
        stdout = ""
        if "JavaScript" in argv:
            stdout = json.dumps(
                [
                    {
                        "name": "External Display",
                        "is_main": True,
                        "is_builtin": False,
                        "visible": [0, 0, 2560, 1415],
                    },
                    {
                        "name": "Built-in Retina Display",
                        "is_main": False,
                        "is_builtin": True,
                        "visible": [-1512, 0, 1512, 982],
                    },
                ]
            )
        elif argv and argv[0] == "osascript" and "is running" in argv[-1]:
            stdout = "false\n"
        return subprocess.CompletedProcess(argv, 0, stdout, "")
