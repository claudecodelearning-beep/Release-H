from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .models import ActionResult, ActionStatus
from .pomodoro import FavoriteClickPlan
from .runner import CommandRunner


SCREEN_DISCOVERY_JXA = r"""
ObjC.import('AppKit');
ObjC.import('CoreGraphics');

(() => {
  const rawScreens = $.NSScreen.screens.js || [];
  if (rawScreens.length === 0) return JSON.stringify([]);

  const mainScreen = $.NSScreen.mainScreen;
  const primaryHeight = Number(mainScreen.frame.size.height);
  const screens = rawScreens.map((screen) => {
    const frame = screen.visibleFrame;
    const displayId = Number(
      screen.deviceDescription.objectForKey('NSScreenNumber').unsignedIntValue
    );
    return {
      name: ObjC.unwrap(screen.localizedName),
      is_main: Boolean(screen.isEqual(mainScreen)),
      is_builtin: Boolean($.CGDisplayIsBuiltin(displayId)),
      visible: [
        Math.round(Number(frame.origin.x)),
        Math.round(primaryHeight - Number(frame.origin.y) - Number(frame.size.height)),
        Math.round(Number(frame.size.width)),
        Math.round(Number(frame.size.height))
      ]
    };
  });
  return JSON.stringify(screens);
})()
"""


@dataclass(frozen=True)
class Screen:
    name: str
    is_main: bool
    is_builtin: bool
    visible: tuple[int, int, int, int]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "Screen":
        visible = tuple(int(value) for value in payload["visible"])
        if len(visible) != 4:
            raise ValueError("Screen visible frame must have four values")
        return cls(
            name=str(payload["name"]),
            is_main=bool(payload["is_main"]),
            is_builtin=bool(payload["is_builtin"]),
            visible=visible,  # type: ignore[arg-type]
        )


def _elapsed_ms(started_ns: int) -> int:
    return max(0, (time.monotonic_ns() - started_ns) // 1_000_000)


def _result(
    action: str,
    started_ns: int,
    returncode: int,
    stdout: str,
    stderr: str,
    success_detail: str,
) -> ActionResult:
    if returncode == 0:
        detail = stdout.strip() or success_detail
        status = ActionStatus.COMPLETED
    else:
        detail = stderr.strip() or stdout.strip() or "macOS layout command failed"
        status = ActionStatus.FAILED
    return ActionResult(action, status, _elapsed_ms(started_ns), detail)


class LayoutController:
    def __init__(
        self,
        runner: CommandRunner,
        video_app_name: str = "哔哩哔哩",
        browser_app_name: str = "Google Chrome",
        script_path: Path | None = None,
    ) -> None:
        self.runner = runner
        self.video_app_name = video_app_name
        self.browser_app_name = browser_app_name
        self.script_path = script_path or Path(__file__).parent / "applescript/layout.scpt"
        self._screens: list[Screen] = []

    def validate_displays(self) -> ActionResult:
        started = time.monotonic_ns()
        response = self.runner.run(
            ["osascript", "-l", "JavaScript", "-e", SCREEN_DISCOVERY_JXA]
        )
        if response.returncode != 0:
            return _result(
                "layout.displays",
                started,
                response.returncode,
                response.stdout,
                response.stderr,
                "",
            )
        try:
            self._screens = [
                Screen.from_dict(item) for item in json.loads(response.stdout)
            ]
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
            return ActionResult(
                "layout.displays",
                ActionStatus.FAILED,
                _elapsed_ms(started),
                f"Unable to parse display geometry: {error}",
            )

        external = any(not screen.is_builtin for screen in self._screens)
        builtin = any(screen.is_builtin for screen in self._screens)
        if not external or not builtin:
            return ActionResult(
                "layout.displays",
                ActionStatus.FAILED,
                _elapsed_ms(started),
                "An external display and the Mac built-in display are required",
            )
        return ActionResult(
            "layout.displays",
            ActionStatus.COMPLETED,
            _elapsed_ms(started),
            "External and built-in displays detected",
        )

    def _screen(self, role: str) -> Screen:
        if not self._screens:
            validation = self.validate_displays()
            if validation.status is ActionStatus.FAILED:
                raise RuntimeError(validation.detail)
        if role == "external":
            return next(screen for screen in self._screens if not screen.is_builtin)
        if role == "builtin":
            return next(screen for screen in self._screens if screen.is_builtin)
        raise ValueError(f"Unknown display role: {role}")

    def _run_script(self, action: str, *arguments: str) -> ActionResult:
        started = time.monotonic_ns()
        response = self.runner.run(
            ["osascript", str(self.script_path), action, *arguments], timeout=45
        )
        return _result(
            f"layout.{action}",
            started,
            response.returncode,
            response.stdout,
            response.stderr,
            f"Completed {action}",
        )

    def arrange_work_space(
        self, vscode_name: str, terminal_name: str
    ) -> ActionResult:
        screen = self._screen("external")
        return self._run_script(
            "arrange-work-space",
            vscode_name,
            terminal_name,
            *(str(value) for value in screen.visible),
        )

    def fullscreen_on_display(
        self, key: str, app_name: str, display_role: str
    ) -> ActionResult:
        screen = self._screen(display_role)
        result = self._run_script(
            "fullscreen",
            app_name,
            *(str(value) for value in screen.visible),
        )
        return ActionResult(
            f"layout.{key}", result.status, result.elapsed_ms, result.detail
        )

    def open_pomodoro(self, plan: FavoriteClickPlan) -> ActionResult:
        started = time.monotonic_ns()
        screen = self._screen("builtin")
        opened = self.runner.run(
            ["open", "-a", self.video_app_name], timeout=15
        )
        if opened.returncode != 0:
            return _result(
                "layout.open-pomodoro",
                started,
                opened.returncode,
                opened.stdout,
                opened.stderr,
                "",
            )
        result = self._run_script(
            "open-favorite-pomodoro",
            self.video_app_name,
            plan.folder_name,
            plan.search_text,
            str(plan.page_downs),
            str(plan.column),
            *(str(value) for value in screen.visible),
        )
        return ActionResult(
            "layout.open-pomodoro",
            result.status,
            _elapsed_ms(started),
            result.detail,
        )

    def open_web_pomodoro(self, url: str) -> ActionResult:
        started = time.monotonic_ns()
        screen = self._screen("builtin")
        opened = self.runner.run(
            ["open", "-a", self.browser_app_name, url], timeout=15
        )
        if opened.returncode != 0:
            return _result(
                "layout.open-web-pomodoro",
                started,
                opened.returncode,
                opened.stdout,
                opened.stderr,
                "",
            )
        result = self._run_script(
            "open-web-pomodoro",
            self.browser_app_name,
            url,
            "500",
            "430",
            "3",
            *(str(value) for value in screen.visible),
        )
        return ActionResult(
            "layout.open-web-pomodoro",
            result.status,
            _elapsed_ms(started),
            result.detail,
        )
