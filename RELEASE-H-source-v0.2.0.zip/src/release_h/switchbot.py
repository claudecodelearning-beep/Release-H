"""Local SwitchBot BLE control; no account credentials or Hub required."""
from __future__ import annotations

import hashlib
import json
import os
import plistlib
import re
import subprocess
import time
import uuid
from pathlib import Path

from .agent_queue import _atomic_json_write, default_runtime_dir
from .models import ActionResult, ActionStatus

ROLES = ("coffee", "air_conditioner")


def normalize_identifier(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("Bot identifier must be a Bluetooth UUID or MAC address")
    if re.fullmatch(r"[0-9a-fA-F]{2}([:-][0-9a-fA-F]{2}){5}", value):
        return value.replace("-", ":").upper()
    if re.fullmatch(r"[0-9a-fA-F]{12}", value):
        return ":".join(value[index:index + 2] for index in range(0, 12, 2)).upper()
    return str(uuid.UUID(value))


def helper_path() -> Path:
    return Path(os.environ.get(
        "RELEASE_H_BLE_HELPER",
        str(Path.home() / "Applications/RELEASE H Agent.app/Contents/MacOS/ReleaseHAgent"),
    ))


def invoke_ble(operation: str, identifier: str | None = None) -> dict:
    helper = helper_path()
    # Older Agent binaries ignore CLI arguments and launch the desktop daemon.
    # Reject them before spawning, so a missing update cannot start a second Agent.
    with (helper.parent.parent / "Info.plist").open("rb") as stream:
        if plistlib.load(stream).get("ReleaseHBluetoothProtocolVersion") != 1:
            raise RuntimeError("Install the Bluetooth-enabled RELEASE H Agent first")
    arguments = [str(helper), "--ble", operation]
    if identifier is not None:
        arguments.append(normalize_identifier(identifier))
    response = subprocess.run(arguments, capture_output=True, text=True, timeout=35)
    try:
        result = json.loads(response.stdout)
    except (ValueError, TypeError) as error:
        raise RuntimeError("BLE helper unavailable; build/install the updated Agent first") from error
    if response.returncode or result.get("status") != "completed":
        raise RuntimeError(result.get("detail", "Bluetooth operation failed"))
    return result


def load_bindings(root: Path) -> dict[str, str]:
    path = root / "switchbot.json"
    if not path.exists():
        return {}
    payload = json.loads(path.read_text())
    if not isinstance(payload, dict) or set(payload) - set(ROLES):
        raise ValueError("switchbot.json must map coffee/air_conditioner to scanned UUIDs")
    bindings = {role: normalize_identifier(value) for role, value in payload.items()}
    if len(set(bindings.values())) != len(bindings):
        raise ValueError("Each role must use a different Bot")
    return bindings


def bind_bot(root: Path, role: str, identifier: str) -> None:
    if role not in ROLES:
        raise ValueError("Unknown Bot role")
    identifier = normalize_identifier(identifier)
    bindings = load_bindings(root)
    if identifier in {value for key, value in bindings.items() if key != role}:
        raise ValueError("This Bot is already assigned to another role")
    bindings[role] = identifier
    _atomic_json_write(root / "switchbot.json", bindings)


class SwitchBotAdapter:
    def __init__(self, root: Path | None = None, *, dry_run=False, request_id=None,
                 transport=invoke_ble):
        self.root = root or default_runtime_dir()
        self.dry_run = dry_run
        self.request_id = request_id
        self.transport = transport

    def press(self, name: str) -> ActionResult:
        started = time.monotonic_ns()
        def result(status, detail):
            return ActionResult(f"device.{name}", status,
                                (time.monotonic_ns() - started) // 1_000_000, detail)
        try:
            bindings = load_bindings(self.root)
            if name not in bindings:
                return result(ActionStatus.PENDING_HARDWARE, f"No Bot configured for {name}")
            if self.dry_run:
                return result(ActionStatus.SKIPPED, "Dry run: would press configured Bot once")
            journal = None
            if self.request_id is not None:
                key = hashlib.sha256(self.request_id.encode()).hexdigest()
                journal = self.root / "bot-attempts" / key / f"{name}.json"
                journal.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                # Claim BEFORE sending a physical command. Interrupted/uncertain
                # actions are never retried automatically, including after restart.
                try:
                    descriptor = os.open(journal, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                except FileExistsError:
                    try:
                        saved = json.loads(journal.read_text())
                        return ActionResult(saved["action"], ActionStatus(saved["status"]),
                                            saved["elapsed_ms"], saved["detail"])
                    except (ValueError, KeyError, TypeError):
                        return result(ActionStatus.FAILED, "Previous attempt uncertain; not pressed again")
                with os.fdopen(descriptor, "w") as stream:
                    json.dump(result(ActionStatus.FAILED,
                                     "Attempt interrupted or in progress; not pressed again").to_dict(), stream)
                    stream.flush()
                    os.fsync(stream.fileno())
            try:
                reply = self.transport("press", bindings[name])
                outcome = result(ActionStatus.COMPLETED, reply.get("detail", "Bot acknowledged one press"))
            except Exception as error:
                outcome = result(ActionStatus.FAILED, str(error))
            if journal is not None:
                _atomic_json_write(journal, outcome.to_dict())
            return outcome
        except Exception as error:
            return result(ActionStatus.FAILED, str(error))


def run_hardware(request_id: str, root: Path | None = None) -> list[dict]:
    adapter = SwitchBotAdapter(root, request_id=request_id)
    return [adapter.press(role).to_dict() for role in ROLES]
