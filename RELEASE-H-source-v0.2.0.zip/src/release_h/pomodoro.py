from __future__ import annotations

import json
import random
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable


@dataclass(frozen=True)
class Video:
    bvid: str
    title: str
    url: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Video":
        return cls(str(data["bvid"]), str(data["title"]), str(data["url"]))


def eligible(videos: Iterable[Video]) -> list[Video]:
    markers = ("番茄钟", "study with me", "25/5", "50/10")
    return [
        video
        for video in videos
        if any(marker in video.title.lower() for marker in markers)
    ]


def choose_video(
    videos: Iterable[Video], last_bvid: str | None, rng: random.Random
) -> Video:
    choices = list(videos)
    if not choices:
        raise ValueError("No eligible pomodoro videos are available")
    if len(choices) > 1 and last_bvid:
        choices = [video for video in choices if video.bvid != last_bvid] or choices
    return rng.choice(choices)


def parse_creator_response(payload: dict[str, Any]) -> list[Video]:
    if payload.get("code") != 0:
        raise ValueError(f"Bilibili returned code {payload.get('code')}")
    records = payload.get("data", {}).get("list", {}).get("vlist", [])
    videos: list[Video] = []
    for record in records:
        bvid = str(record.get("bvid", "")).strip()
        title = str(record.get("title", "")).strip()
        if bvid and title:
            videos.append(
                Video(bvid, title, f"https://www.bilibili.com/video/{bvid}/")
            )
    return videos


def fetch_creator_videos(mid: int) -> list[Video]:
    query = urllib.parse.urlencode(
        {"mid": mid, "pn": 1, "ps": 50, "order": "pubdate", "jsonp": "jsonp"}
    )
    request = urllib.request.Request(
        f"https://api.bilibili.com/x/space/arc/search?{query}",
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 Chrome/126 Safari/537.36"
            ),
            "Referer": f"https://space.bilibili.com/{mid}/video",
        },
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        payload = json.load(response)
    return parse_creator_response(payload)


def _read_videos(path: Path) -> list[Video]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return [Video.from_dict(item) for item in payload]


def _write_atomic(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(content, encoding="utf-8")
    temporary.replace(path)


@dataclass(frozen=True)
class FavoriteClickPlan:
    folder_name: str
    page_downs: int
    column: int
    search_text: str = "RELEASE H"


class FavoriteFolderSelector:
    def __init__(
        self,
        folder_name: str,
        state_dir: Path,
        max_page_downs: int = 20,
        columns: int = 3,
        rng: random.Random | None = None,
        search_text: str = "RELEASE H",
    ) -> None:
        if max_page_downs < 0:
            raise ValueError("max_page_downs must not be negative")
        if columns < 1:
            raise ValueError("columns must be positive")
        self.folder_name = folder_name
        self.state_dir = state_dir
        self.max_page_downs = max_page_downs
        self.columns = columns
        self.rng = rng or random.SystemRandom()
        self.search_text = search_text

    def select(self) -> FavoriteClickPlan:
        state_path = self.state_dir / "last_favorite_position.json"
        last: tuple[int, int] | None = None
        try:
            payload = json.loads(state_path.read_text(encoding="utf-8"))
            last = (int(payload["page_downs"]), int(payload["column"]))
        except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
            pass

        page_downs = self.rng.randint(0, self.max_page_downs)
        column = self.rng.randrange(self.columns)
        if last == (page_downs, column) and (
            self.max_page_downs > 0 or self.columns > 1
        ):
            if self.columns > 1:
                column = (column + 1) % self.columns
            else:
                page_downs = (page_downs + 1) % (self.max_page_downs + 1)

        plan = FavoriteClickPlan(
            self.folder_name, page_downs, column, self.search_text
        )
        try:
            _write_atomic(
                state_path,
                json.dumps(
                    {"page_downs": plan.page_downs, "column": plan.column},
                    ensure_ascii=False,
                ),
            )
        except OSError:
            pass
        return plan


class PomodoroRepository:
    def __init__(
        self,
        state_dir: Path,
        fetcher: Callable[[], list[Video]],
        fallback_path: Path,
        rng: random.Random | None = None,
    ) -> None:
        self.state_dir = state_dir
        self.fetcher = fetcher
        self.fallback_path = fallback_path
        self.rng = rng or random.SystemRandom()

    def select(self) -> Video:
        try:
            self.state_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        cache_path = self.state_dir / "videos.json"
        last_path = self.state_dir / "last_bvid.txt"

        try:
            videos = eligible(self.fetcher())
            if not videos:
                raise ValueError("Bilibili returned no eligible pomodoro videos")
            _write_atomic(
                cache_path,
                json.dumps(
                    [asdict(video) for video in videos], ensure_ascii=False, indent=2
                ),
            )
        except (OSError, ValueError, KeyError, json.JSONDecodeError):
            source_path = cache_path if cache_path.exists() else self.fallback_path
            videos = eligible(_read_videos(source_path))

        try:
            last_bvid = (
                last_path.read_text(encoding="utf-8").strip()
                if last_path.exists()
                else None
            )
        except OSError:
            last_bvid = None
        selected = choose_video(videos, last_bvid, self.rng)
        try:
            _write_atomic(last_path, selected.bvid + "\n")
        except OSError:
            pass
        return selected
