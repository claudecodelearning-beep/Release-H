from __future__ import annotations

import fcntl
import json
import os
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Mapping


class InvalidRequest(ValueError):
    """Raised when a queue entry does not match the fixed request schema."""


@dataclass(frozen=True)
class AgentRequest:
    request_id: str
    action: str
    requested_at: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class QueuePaths:
    root: Path
    pending: Path
    running: Path
    last_result: Path
    log: Path
    lock: Path

    @classmethod
    def at(cls, root: Path) -> "QueuePaths":
        return cls(
            root=root,
            pending=root / "pending-start-work.json",
            running=root / "running-start-work.json",
            last_result=root / "last-result.json",
            log=root / "agent.log",
            lock=root / "agent.lock",
        )


def default_runtime_dir() -> Path:
    configured = os.environ.get("RELEASE_H_RUNTIME_DIR")
    if configured:
        return Path(configured).expanduser().resolve()
    return Path(__file__).resolve().parents[2] / "runtime"


def _iso_utc(value: datetime | None = None) -> str:
    current = value or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    return current.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _ensure_root(paths: QueuePaths) -> None:
    paths.root.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        paths.root.chmod(0o700)
    except OSError:
        pass


def _atomic_json_write(path: Path, payload: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.parent / f".{path.name}.{uuid.uuid4().hex}.tmp"
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        path.chmod(0o600)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def enqueue_start(
    paths: QueuePaths,
    request_id: str | None = None,
    requested_at: datetime | None = None,
) -> AgentRequest:
    _ensure_root(paths)
    request = AgentRequest(
        request_id=request_id or str(uuid.uuid4()),
        action="start-work",
        requested_at=_iso_utc(requested_at),
    )
    _atomic_json_write(paths.pending, request.to_dict())
    return request


def _validate_request(payload: object) -> AgentRequest:
    if not isinstance(payload, dict):
        raise InvalidRequest("Request must be a JSON object")
    required = {"request_id", "action", "requested_at"}
    if set(payload) != required:
        raise InvalidRequest("Request must contain only the fixed queue fields")
    request_id = payload.get("request_id")
    action = payload.get("action")
    requested_at = payload.get("requested_at")
    if not isinstance(request_id, str) or not request_id or len(request_id) > 128:
        raise InvalidRequest("Request ID must be a non-empty string")
    if action != "start-work":
        raise InvalidRequest("Only the start-work action is allowed")
    if not isinstance(requested_at, str):
        raise InvalidRequest("Request timestamp must be a string")
    try:
        datetime.fromisoformat(requested_at.replace("Z", "+00:00"))
    except ValueError as error:
        raise InvalidRequest("Request timestamp is invalid") from error
    return AgentRequest(request_id, action, requested_at)


def load_request(path: Path) -> AgentRequest:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise InvalidRequest(f"Unable to read request: {error}") from error
    return _validate_request(payload)


def _quarantine(path: Path) -> Path:
    target = path.with_name(f"{path.stem}-{uuid.uuid4().hex}.invalid")
    os.replace(path, target)
    target.chmod(0o600)
    return target


def claim_request(paths: QueuePaths) -> AgentRequest | None:
    _ensure_root(paths)
    try:
        os.replace(paths.pending, paths.running)
    except FileNotFoundError:
        return None
    try:
        return load_request(paths.running)
    except InvalidRequest:
        _quarantine(paths.running)
        raise


def recover_interrupted(paths: QueuePaths) -> bool:
    _ensure_root(paths)
    if not paths.running.exists():
        return False
    if paths.pending.exists():
        _quarantine(paths.running)
        return True
    os.replace(paths.running, paths.pending)
    paths.pending.chmod(0o600)
    return True


def write_result(
    paths: QueuePaths,
    request: AgentRequest,
    execution: Mapping[str, object],
) -> None:
    _ensure_root(paths)
    _atomic_json_write(
        paths.last_result,
        {"request": request.to_dict(), "execution": dict(execution)},
    )


@contextmanager
def acquire_agent_lock(paths: QueuePaths) -> Iterator[bool]:
    _ensure_root(paths)
    descriptor = os.open(paths.lock, os.O_RDWR | os.O_CREAT, 0o600)
    stream = os.fdopen(descriptor, "r+")
    acquired = False
    try:
        try:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            acquired = True
        except BlockingIOError:
            pass
        yield acquired
    finally:
        if acquired:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        stream.close()
