on integerValue(valueText)
    return valueText as integer
end integerValue

on frontWindowFor(appName)
    tell application appName
        set appBundleId to id
        activate
    end tell
    delay 1
    tell application "System Events"
        repeat 20 times
            if exists first application process whose bundle identifier is appBundleId then exit repeat
            delay 0.25
        end repeat
        set targetProcess to first application process whose bundle identifier is appBundleId
        set visible of targetProcess to true
        set frontmost of targetProcess to true

        repeat 12 times
            if exists window 1 of targetProcess then
                set targetWindow to window 1 of targetProcess
                try
                    set value of attribute "AXMinimized" of targetWindow to false
                end try
                return targetWindow
            end if
            delay 0.25
        end repeat

        keystroke "n" using {command down}
        repeat 12 times
            if exists window 1 of targetProcess then return window 1 of targetProcess
            delay 0.25
        end repeat
    end tell
    error "No accessible window found for " & appName
end frontWindowFor

on placeWindow(appName, targetX, targetY, targetWidth, targetHeight)
    set targetWindow to my frontWindowFor(appName)
    tell application "System Events"
        try
            set value of attribute "AXFullScreen" of targetWindow to false
            delay 1
        end try
        set position of targetWindow to {targetX, targetY}
        set size of targetWindow to {targetWidth, targetHeight}
    end tell
end placeWindow

on makeFullscreen(appName, targetX, targetY, targetWidth, targetHeight)
    my placeWindow(appName, targetX, targetY, targetWidth, targetHeight)
    delay 0.5
    set targetWindow to my frontWindowFor(appName)
    tell application "System Events"
        set value of attribute "AXFullScreen" of targetWindow to true
    end tell
    delay 2
end makeFullscreen

on clickRelative(targetWindow, xPermille, yPermille)
    tell application "System Events"
        set windowPosition to position of targetWindow
        set windowSize to size of targetWindow
        set clickX to (item 1 of windowPosition) + ((item 1 of windowSize) * xPermille div 1000)
        set clickY to (item 2 of windowPosition) + ((item 2 of windowSize) * yPermille div 1000)
        click at {clickX, clickY}
    end tell
    delay 0.7
end clickRelative

on run argv
    if (count of argv) < 1 then error "Missing layout action"
    set actionName to item 1 of argv

    if actionName is "arrange-work-space" then
        set vscodeName to item 2 of argv
        set terminalName to item 3 of argv
        set targetX to my integerValue(item 4 of argv)
        set targetY to my integerValue(item 5 of argv)
        set targetWidth to my integerValue(item 6 of argv)
        set targetHeight to my integerValue(item 7 of argv)
        set leftWidth to targetWidth div 2
        set rightWidth to targetWidth - leftWidth
        my placeWindow(vscodeName, targetX, targetY, leftWidth, targetHeight)
        my placeWindow(terminalName, targetX + leftWidth, targetY, rightWidth, targetHeight)
        return "VS Code and Terminal arranged on the external display"
    else if actionName is "fullscreen" then
        set appName to item 2 of argv
        set targetX to my integerValue(item 3 of argv)
        set targetY to my integerValue(item 4 of argv)
        set targetWidth to my integerValue(item 5 of argv)
        set targetHeight to my integerValue(item 6 of argv)
        my makeFullscreen(appName, targetX, targetY, targetWidth, targetHeight)
        return appName & " entered full screen"
    else if actionName is "open-favorite-pomodoro" then
        set videoAppName to item 2 of argv
        set folderName to item 3 of argv
        set folderSearchText to item 4 of argv
        set pageDownCount to my integerValue(item 5 of argv)
        set selectedColumn to my integerValue(item 6 of argv)
        set targetX to my integerValue(item 7 of argv)
        set targetY to my integerValue(item 8 of argv)
        set targetWidth to my integerValue(item 9 of argv)
        set targetHeight to my integerValue(item 10 of argv)
        delay 3
        my placeWindow(videoAppName, targetX, targetY, targetWidth, targetHeight)
        set targetWindow to my frontWindowFor(videoAppName)

        -- Navigate from any ordinary Bilibili page to My Favorites.
        my clickRelative(targetWindow, 20, 323)
        delay 1.5
        my clickRelative(targetWindow, 198, 268)
        delay 1.5
        my clickRelative(targetWindow, 146, 319)
        delay 1

        -- Filter by the stable ASCII part of the folder name, then open it.
        my clickRelative(targetWindow, 886, 267)
        set savedClipboard to the clipboard
        set the clipboard to folderSearchText
        tell application "System Events"
            keystroke "a" using {command down}
            keystroke "v" using {command down}
        end tell
        set the clipboard to savedClipboard
        delay 2
        my clickRelative(targetWindow, 148, 454)
        delay 3

        -- Reset to the first row, then choose a random page and one of three columns.
        tell application "System Events"
            key code 115
            delay 0.5
            repeat pageDownCount times
                key code 121
                delay 0.2
            end repeat
        end tell
        if selectedColumn is 0 then
            set cardX to 148
        else if selectedColumn is 1 then
            set cardX to 333
        else
            set cardX to 519
        end if
        my clickRelative(targetWindow, cardX, 311)
        delay 5

        my makeFullscreen(videoAppName, targetX, targetY, targetWidth, targetHeight)
        delay 2
        tell application "System Events"
            keystroke "f"
        end tell
        return "Random video opened from " & folderName & " on the built-in display"
    else if actionName is "open-web-pomodoro" then
        set browserAppName to item 2 of argv
        set videoURL to item 3 of argv
        set playerFocusX to my integerValue(item 4 of argv)
        set playerFocusY to my integerValue(item 5 of argv)
        set fullscreenKeyCode to my integerValue(item 6 of argv)
        set targetX to my integerValue(item 7 of argv)
        set targetY to my integerValue(item 8 of argv)
        set targetWidth to my integerValue(item 9 of argv)
        set targetHeight to my integerValue(item 10 of argv)
        delay 5
        my makeFullscreen(browserAppName, targetX, targetY, targetWidth, targetHeight)
        delay 2
        set browserWindow to my frontWindowFor(browserAppName)
        my clickRelative(browserWindow, playerFocusX, playerFocusY)
        tell application "System Events"
            key code fullscreenKeyCode
            delay 1
            key code 49
        end tell
        return "Web pomodoro opened on the built-in display: " & videoURL
    end if

    error "Unknown layout action: " & actionName
end run
