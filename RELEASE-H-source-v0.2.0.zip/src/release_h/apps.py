import time

from .models import ActionResult, ActionStatus
from .runner import CommandRunner


def _elapsed_ms(started_ns: int) -> int:
    return max(0, (time.monotonic_ns() - started_ns) // 1_000_000)


def _apple_script_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


class ApplicationController:
    def __init__(self, runner: CommandRunner) -> None:
        self.runner = runner

    def ensure_open(self, key: str, app_name: str) -> ActionResult:
        started = time.monotonic_ns()
        escaped_name = _apple_script_string(app_name)
        probe = self.runner.run(
            ["osascript", "-e", f'application "{escaped_name}" is running']
        )
        if probe.returncode != 0:
            detail = probe.stderr.strip() or "Unable to read application status"
            return ActionResult(
                f"apps.{key}", ActionStatus.FAILED, _elapsed_ms(started), detail
            )

        if probe.stdout.strip().lower() == "true":
            return ActionResult(
                f"apps.{key}",
                ActionStatus.ALREADY_RUNNING,
                _elapsed_ms(started),
                f"{app_name} is already running",
            )

        launched = self.runner.run(["open", "-a", app_name])
        if launched.returncode != 0:
            detail = launched.stderr.strip() or f"Unable to open {app_name}"
            return ActionResult(
                f"apps.{key}", ActionStatus.FAILED, _elapsed_ms(started), detail
            )
        return ActionResult(
            f"apps.{key}",
            ActionStatus.OPENED,
            _elapsed_ms(started),
            f"Opened {app_name}",
        )
