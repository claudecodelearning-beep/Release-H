from __future__ import annotations

import time
from collections.abc import Callable

from .apps import ApplicationController
from .devices import DeviceAdapter
from .layout import LayoutController
from .models import ActionResult, ActionStatus
from .pomodoro import FavoriteClickPlan, FavoriteFolderSelector, PomodoroRepository, Video


def _failed(action: str, started_ns: int, error: Exception) -> ActionResult:
    return ActionResult(
        action=action,
        status=ActionStatus.FAILED,
        elapsed_ms=max(0, (time.monotonic_ns() - started_ns) // 1_000_000),
        detail=str(error) or error.__class__.__name__,
    )


class StartWorkWorkflow:
    def __init__(
        self,
        apps: ApplicationController,
        pomodoro: FavoriteFolderSelector | PomodoroRepository,
        layout: LayoutController,
        devices: DeviceAdapter,
        app_names: dict[str, str],
        device_actions: tuple[str, ...],
        pomodoro_mode: str = "app",
    ) -> None:
        self.apps = apps
        self.pomodoro = pomodoro
        self.layout = layout
        self.devices = devices
        self.app_names = app_names
        self.device_actions = device_actions
        self.pomodoro_mode = pomodoro_mode

    @staticmethod
    def _attempt(action: str, operation: Callable[[], ActionResult]) -> ActionResult:
        started = time.monotonic_ns()
        try:
            result = operation()
            return ActionResult(
                action,
                result.status,
                result.elapsed_ms,
                result.detail,
            )
        except Exception as error:  # Keep unrelated workflow actions running.
            return _failed(action, started, error)

    @staticmethod
    def _skip(action: str, reason: str) -> ActionResult:
        return ActionResult(action, ActionStatus.SKIPPED, 0, reason)

    def run(self) -> list[ActionResult]:
        results: list[ActionResult] = []

        display_result = self._attempt(
            "layout.displays", self.layout.validate_displays
        )
        results.append(display_result)

        for key in ("vscode", "terminal", "notes", "codex", "claude"):
            results.append(
                self._attempt(
                    f"apps.{key}",
                    lambda key=key: self.apps.ensure_open(key, self.app_names[key]),
                )
            )

        selected: FavoriteClickPlan | Video | None = None
        started = time.monotonic_ns()
        try:
            selected = self.pomodoro.select()
            if isinstance(selected, FavoriteClickPlan):
                selection_detail = (
                    f"{selected.folder_name} — random page-downs "
                    f"{selected.page_downs}, column {selected.column + 1}"
                )
            else:
                selection_detail = f"{selected.title} — {selected.url}"
            results.append(
                ActionResult(
                    "pomodoro.select",
                    ActionStatus.COMPLETED,
                    max(0, (time.monotonic_ns() - started) // 1_000_000),
                    selection_detail,
                )
            )
        except Exception as error:
            results.append(_failed("pomodoro.select", started, error))

        display_ready = display_result.status is not ActionStatus.FAILED
        if display_ready:
            layout_actions: list[tuple[str, Callable[[], ActionResult]]] = [
                (
                    "layout.vscode",
                    lambda: self.layout.fullscreen_on_display(
                        "vscode", self.app_names["vscode"], "external"
                    ),
                ),
                (
                    "layout.terminal",
                    lambda: self.layout.fullscreen_on_display(
                        "terminal", self.app_names["terminal"], "external"
                    ),
                ),
                (
                    "layout.notes",
                    lambda: self.layout.fullscreen_on_display(
                        "notes", self.app_names["notes"], "external"
                    ),
                ),
                (
                    "layout.codex",
                    lambda: self.layout.fullscreen_on_display(
                        "codex", self.app_names["codex"], "external"
                    ),
                ),
            ]
            for action, operation in layout_actions:
                results.append(self._attempt(action, operation))

            if selected is None:
                results.append(
                    self._skip("layout.pomodoro", "No pomodoro video was selected")
                )
            else:
                if self.pomodoro_mode == "web" and isinstance(selected, Video):
                    results.append(
                        self._attempt(
                            "layout.pomodoro",
                            lambda: self.layout.open_web_pomodoro(selected.url),
                        )
                    )
                elif isinstance(selected, FavoriteClickPlan):
                    results.append(
                        self._attempt(
                            "layout.pomodoro",
                            lambda: self.layout.open_pomodoro(selected),
                        )
                    )
                else:
                    results.append(
                        self._skip(
                            "layout.pomodoro",
                            "Pomodoro selection does not match the chosen mode",
                        )
                    )
            results.append(
                self._attempt(
                    "layout.claude",
                    lambda: self.layout.fullscreen_on_display(
                        "claude", self.app_names["claude"], "builtin"
                    ),
                )
            )
        else:
            reason = "Required external and built-in display setup is unavailable"
            for action in (
                "layout.vscode",
                "layout.terminal",
                "layout.notes",
                "layout.codex",
                "layout.pomodoro",
                "layout.claude",
            ):
                results.append(self._skip(action, reason))

        for name in self.device_actions:
            results.append(
                self._attempt(
                    f"device.{name}", lambda name=name: self.devices.press(name)
                )
            )

        return results
