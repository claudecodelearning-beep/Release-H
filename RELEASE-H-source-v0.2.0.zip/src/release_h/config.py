from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class WorkflowConfig:
    state_dir: Path
    bilibili_mid: int
    favorite_folder_name: str
    favorite_search_text: str
    favorite_max_page_downs: int
    favorite_columns: int
    device_actions: tuple[str, ...]
    app_names: dict[str, str]
    video_app_name: str
    browser_app_name: str


def default_config(state_dir: Path | None = None) -> WorkflowConfig:
    root = state_dir or Path.home() / "Library/Application Support/release-h"
    return WorkflowConfig(
        state_dir=root,
        bilibili_mid=487014659,
        favorite_folder_name="RELEASE H 番茄钟",
        favorite_search_text="RELEASE H",
        favorite_max_page_downs=20,
        favorite_columns=3,
        device_actions=("coffee", "air_conditioner", "standing_desk"),
        app_names={
            "vscode": "Visual Studio Code",
            "terminal": "Terminal",
            "notes": "Notes",
            "codex": "Codex",
            "claude": "Claude",
        },
        video_app_name="哔哩哔哩",
        browser_app_name="Google Chrome",
    )
