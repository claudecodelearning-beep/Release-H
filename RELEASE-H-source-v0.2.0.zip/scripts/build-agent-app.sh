#!/bin/sh
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
DIST_DIR="$PROJECT_DIR/dist"
APP_BUNDLE="$DIST_DIR/RELEASE H Agent.app"
APP_ARCHIVE="$DIST_DIR/RELEASE-H-Agent.zip"
BUILD_DIR=$(mktemp -d /tmp/release-h-agent-build.XXXXXX)
BUILD_APP="$BUILD_DIR/RELEASE H Agent.app"
CONTENTS_DIR="$BUILD_APP/Contents"
MACOS_DIR="$CONTENTS_DIR/MacOS"
INFO_PLIST="$CONTENTS_DIR/Info.plist"
MODULE_CACHE="$BUILD_DIR/swift-module-cache"

cleanup() {
    rm -rf "$BUILD_DIR"
}
trap cleanup EXIT

mkdir -p "$MACOS_DIR"
mkdir -p "$MODULE_CACHE"
cp "$PROJECT_DIR/agent/macos/Info.plist.in" "$INFO_PLIST"
/usr/bin/plutil -replace ReleaseHProjectPath -string "$PROJECT_DIR" "$INFO_PLIST"

/usr/bin/xcrun swiftc "$PROJECT_DIR/agent/macos/main.swift" \
    "$PROJECT_DIR/agent/macos/Bluetooth.swift" \
    -module-cache-path "$MODULE_CACHE" \
    -framework AppKit \
    -framework ApplicationServices \
    -framework CoreBluetooth \
    -o "$MACOS_DIR/ReleaseHAgent"

/usr/bin/xattr -cr "$BUILD_APP"
/usr/bin/codesign --force --deep --sign - \
    --identifier com.releaseh.agent "$BUILD_APP"
/usr/bin/codesign --verify --deep --strict "$BUILD_APP"

if [ -e "$APP_BUNDLE" ]; then
    rm -rf "$APP_BUNDLE"
fi
if [ -e "$APP_ARCHIVE" ]; then
    rm -f "$APP_ARCHIVE"
fi
mkdir -p "$DIST_DIR"
/usr/bin/ditto -c -k --keepParent \
    --norsrc --noextattr --noqtn --noacl \
    "$BUILD_APP" "$APP_ARCHIVE"

echo "已构建并验签：$APP_ARCHIVE"
