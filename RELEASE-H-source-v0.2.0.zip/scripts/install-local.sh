#!/bin/sh
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
VENV_DIR="$PROJECT_DIR/.venv"

python3 -m venv "$VENV_DIR"
ln -sf "$PROJECT_DIR/bin/release-h" "$VENV_DIR/bin/release-h"
"$PROJECT_DIR/scripts/build-agent-app.sh"

echo
echo "RELEASE H 已安装：$VENV_DIR/bin/release-h"
echo "先验证：$VENV_DIR/bin/release-h start-work --dry-run"
echo "安装常驻 Agent：$PROJECT_DIR/scripts/install-agent.sh"
echo
echo "首次真实运行前，请在 macOS 中完成："
echo "1. 系统设置 → 隐私与安全性 → 辅助功能：允许 RELEASE H Agent"
echo "2. 系统设置 → 隐私与安全性 → 自动化：允许 RELEASE H Agent 控制 System Events 和目标 App"
echo "3. 系统设置 → 桌面与程序坞 → Mission Control：开启‘显示器具有单独的空间’"
