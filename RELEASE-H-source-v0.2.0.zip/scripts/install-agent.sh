#!/bin/sh
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SOURCE_ARCHIVE="$PROJECT_DIR/dist/RELEASE-H-Agent.zip"
INSTALL_DIR="$HOME/Applications"
INSTALL_APP="$INSTALL_DIR/RELEASE H Agent.app"
LAUNCH_DIR="$HOME/Library/LaunchAgents"
LAUNCH_PLIST="$LAUNCH_DIR/com.releaseh.agent.plist"
RUNTIME_DIR="$PROJECT_DIR/runtime"
SERVICE_TARGET="gui/$(id -u)/com.releaseh.agent"
STAGING_DIR=$(mktemp -d /tmp/release-h-agent-install.XXXXXX)
STAGED_APP="$STAGING_DIR/RELEASE H Agent.app"

cleanup() {
    rm -rf "$STAGING_DIR"
}
trap cleanup EXIT

"$PROJECT_DIR/scripts/build-agent-app.sh"
/usr/bin/ditto -x -k --norsrc --noextattr --noqtn --noacl \
    "$SOURCE_ARCHIVE" "$STAGING_DIR"
/usr/bin/xattr -cr "$STAGED_APP"
/usr/bin/codesign --verify --deep --strict "$STAGED_APP"
mkdir -p "$INSTALL_DIR" "$LAUNCH_DIR" "$RUNTIME_DIR"
chmod 700 "$RUNTIME_DIR"

if /bin/launchctl print "$SERVICE_TARGET" >/dev/null 2>&1; then
    /bin/launchctl bootout "$SERVICE_TARGET"
fi
if [ -e "$INSTALL_APP" ]; then
    rm -rf "$INSTALL_APP"
fi
/usr/bin/ditto "$STAGED_APP" "$INSTALL_APP"
/usr/bin/xattr -cr "$INSTALL_APP"
/usr/bin/codesign --verify --deep --strict "$INSTALL_APP"

cp "$PROJECT_DIR/agent/macos/com.releaseh.agent.plist.in" "$LAUNCH_PLIST"
/usr/bin/plutil -replace ProgramArguments -json '[]' "$LAUNCH_PLIST"
/usr/bin/plutil -insert ProgramArguments.0 \
    -string "$INSTALL_APP/Contents/MacOS/ReleaseHAgent" "$LAUNCH_PLIST"
/usr/bin/plutil -replace StandardOutPath \
    -string "$RUNTIME_DIR/launch-agent.stdout.log" "$LAUNCH_PLIST"
/usr/bin/plutil -replace StandardErrorPath \
    -string "$RUNTIME_DIR/launch-agent.stderr.log" "$LAUNCH_PLIST"
/bin/chmod 600 "$LAUNCH_PLIST"

/bin/launchctl bootstrap "gui/$(id -u)" "$LAUNCH_PLIST"

echo "已安装并启动：$INSTALL_APP"
echo "下一步：在系统设置的‘辅助功能’中允许 RELEASE H Agent。"
echo "SwitchBot：运行 $PROJECT_DIR/.venv/bin/release-h bot scan --json，并允许蓝牙访问。"
echo "然后运行一次：$PROJECT_DIR/.venv/bin/release-h request-start --json"
