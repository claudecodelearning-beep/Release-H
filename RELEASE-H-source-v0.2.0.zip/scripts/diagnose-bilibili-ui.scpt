on joinText(textItems, separatorText)
    set previousDelimiters to AppleScript's text item delimiters
    set AppleScript's text item delimiters to separatorText
    set joinedText to textItems as text
    set AppleScript's text item delimiters to previousDelimiters
    return joinedText
end joinText

on run
    set bundleId to "com.bilibili.bilibiliPC"
    set outputRows to {}

    tell application "System Events"
        if not (exists first application process whose bundle identifier is bundleId) then error "哔哩哔哩 is not running"
        set targetProcess to first application process whose bundle identifier is bundleId
        if not (exists window 1 of targetProcess) then error "哔哩哔哩 has no accessible window"

        repeat with uiElement in entire contents of window 1 of targetProcess
            set roleText to ""
            set titleText to ""
            set descriptionText to ""
            set valueText to ""
            set actionText to ""
            set positionText to ""
            set sizeText to ""

            try
                set roleText to role of uiElement as text
            end try
            try
                set titleText to title of uiElement as text
            end try
            try
                set descriptionText to description of uiElement as text
            end try
            try
                set valueText to value of uiElement as text
            end try
            try
                set actionText to my joinText(name of every action of uiElement, ",")
            end try
            try
                set elementPosition to position of uiElement
                set positionText to (item 1 of elementPosition as text) & "," & (item 2 of elementPosition as text)
            end try
            try
                set elementSize to size of uiElement
                set sizeText to (item 1 of elementSize as text) & "x" & (item 2 of elementSize as text)
            end try

            if roleText is "AXButton" or roleText is "AXLink" or roleText is "AXStaticText" or roleText is "AXTextField" or actionText contains "AXPress" then
                set end of outputRows to roleText & " | title=" & titleText & " | desc=" & descriptionText & " | value=" & valueText & " | actions=" & actionText & " | pos=" & positionText & " | size=" & sizeText
            end if
        end repeat
    end tell

    if (count of outputRows) is 0 then return "NO_MATCHING_UI_ELEMENTS"
    return my joinText(outputRows, linefeed)
end run
