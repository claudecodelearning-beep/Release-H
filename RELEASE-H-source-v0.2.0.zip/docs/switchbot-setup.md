# SwitchBot：空调蓝牙接入

以下以一个用于空调的 Bot 为例。只绑定实际拥有的设备，未配置设备不会动作。

## 首次设置

1. 在手机 SwitchBot App 添加 Bot，设置为 **按压 / Press 模式**，确认手动按压能操作空调。
2. 在设备信息中找到 MAC 地址。App 自定义名称不保证出现在蓝牙广播中。
3. 在 Mac Terminal 更新本地 Agent：

   ```sh
   cd /path/to/release-h
   ./scripts/install-agent.sh
   .venv/bin/release-h bot scan --json
   ```

   首次扫描时在系统弹窗中允许蓝牙访问。若没有权限，在系统设置 → 隐私与安全性 → 蓝牙中允许 RELEASE H Agent（若系统标明 Terminal，则允许该实际发起程序）。更新后也检查 Agent 原有辅助功能、自动化权限是否仍有效。

4. 用 App 的 MAC 地址，或扫描到的 UUID 绑定。把下面占位符替换成实际值：

   ```sh
   .venv/bin/release-h bot bind air_conditioner <MAC或UUID> --json
   .venv/bin/release-h bot status --json
   ```

5. 确认空调适合按一次后进行实机测试：

   ```sh
   .venv/bin/release-h bot press air_conditioner --json
   ```

   `completed` 表示收到 Bot 的成功回执，仍需肉眼确认机械臂确实按到了空调按钮。

## 日常使用

原指令不变：

```sh
.venv/bin/release-h request-start --json
```

更新后的 Agent 读取请求后先执行已绑定的 Bot，再判断锁屏状态。Mac 醒着但锁屏时可先尝试蓝牙按压；桌面工作流等待解锁。Mac 进入系统睡眠时不能保证执行；锁屏蓝牙需要在这台 Mac 上实测。

每个请求、每个 Bot 的尝试记录保存在 `runtime/bot-attempts/`，写入记录后才发送按压。同一请求在轮询、解锁、进程重启、队列恢复时不会重新发送。收到拒绝、超时或中断时也不自动重试，因为按钮可能已经按下。再次提交 `request-start` 会创建新请求，可能再按一次。

按压空调电源是开/关切换，不读取空调实际状态。Bot 回执只能确认机械臂动作，不能证明空调开机。

`start-work` 直接运行时依旧执行桌面和硬件；Agent 内部使用 `start-work --skip-devices`，避免硬件重复执行。`--dry-run` 不扫描、不连接、不按压。未绑定设备保持 `pending_hardware`。

## 限制与排查

- `Bluetooth LE is unavailable`：当前执行环境未能访问蓝牙，先从 Mac Terminal 测试，不据此断言硬件损坏。
- 找不到 Bot：检查电池、Mac 蓝牙、距离；暂时退出手机上的 Bot 控制页面后重试扫描。
- Switch 模式：在 App 中改为 Press 模式；程序不自动修改 Bot 模式。
- 设备启用了密码/加密：本版本不实现密码认证，会拒绝发送；不要把账号密码填进命令。
- 一次未收到回执：先确认空调状态，再决定是否发送新请求。

协议来源：[SwitchBot 官方 Bot BLE 协议](https://github.com/OpenWonderLabs/SwitchBotAPI-BLE/blob/latest/devicetypes/bot.md)。只使用 `57 01 00` 单次按压，并等待 `01` 成功回执。
