"""Small public view of authorized requests; never exposes execution output."""
import threading
import uuid
from .agent_queue import QueueBusy, InvalidRequest, enqueue_start, load_request
from .web_sessions import ControlError

STATUSES = frozenset({'queued','hardware_running','waiting_unlock','desktop_running','completed','failed','unknown'})

def valid_request_id(value):
    try: return isinstance(value,str) and str(uuid.UUID(value,version=4)) == value and uuid.UUID(value).version == 4
    except (ValueError, TypeError, AttributeError): return False

class ControlState:
    def __init__(self, paths):
        self.paths = paths
        self._lock = threading.Lock()
        self._records = {}
        from .launch_selection import SelectionStore
        self.selection = SelectionStore(paths.root)

    def submit(self, session_id: str, client_id: str, selection=None) -> dict:
        if not valid_request_id(client_id): raise ControlError(400,'invalid_request')
        with self._lock:
            if client_id in self._records: return self._read(session_id,client_id)
            if sum(1 for owner, _ in self._records.values() if owner == session_id) >= 128:
                raise ControlError(429,'request_limit')
            # Retain a tombstone for every admitted ID, even across session revocation.
            if len(self._records) >= 2048: raise ControlError(429,'request_limit')
            queue_id=('web-selection:' if selection is not None else 'web:')+client_id
            snapshot_path=self.selection.request_path('web-selection:'+client_id)
            if snapshot_path.exists():raise ControlError(409,'request_unknown')
            if selection is not None:
                from .agent_queue import _atomic_json_write
                try:snapshot=self.selection.snapshot(selection)
                except ValueError as error:raise ControlError(400,str(error)) from None
                _atomic_json_write(snapshot_path,snapshot)
            try: enqueue_start(self.paths, queue_id, reject_if_busy=True)
            except QueueBusy:
                if selection is not None:snapshot_path.unlink(missing_ok=True)
                raise ControlError(409,'workflow_busy') from None
            self._records[client_id] = [session_id,'queued']
            return self._read(session_id,client_id)

    def _read(self, session_id, client_id):
        record = self._records.get(client_id)
        if not record or record[0] != session_id: raise ControlError(404,'request_unknown')
        return {'request_id':client_id, 'status':record[1]}

    def get_selection(self):
        with self._lock:return self.selection.public()
    def save_selection(self,value):
        with self._lock:self.selection.save(value);return self.selection.public()
    def set_project(self,path):
        with self._lock:self.selection.set_project(path)

    def read(self, session_id, client_id):
        with self._lock:
            result=self._read(session_id,client_id)
            if result['status'] not in {'completed','failed'}:
                present=False
                for path in (self.paths.pending,self.paths.running):
                    try: present = present or load_request(path).request_id in ('web:'+client_id,'web-selection:'+client_id)
                    except InvalidRequest: pass
                if not present:
                    self._records[client_id][1]='unknown'
                    result['status']='unknown'
            return result

    def observe(self, event):
        with self._lock:
            record = self._records.get(event.request_id.split(':',1)[1]) if event.request_id.startswith(('web:','web-selection:')) else None
            if record: record[1] = event.status if event.status in STATUSES else 'unknown'

    def forget_session(self, session_id):
        with self._lock:
            for record in self._records.values():
                if record[0] == session_id: record[0] = None
