"""Fail-closed adapter to the versioned, native user consent dialog."""
import plistlib
import subprocess
from .agent import mac_session_unlocked
from .switchbot import helper_path
from .web_sessions import DEFAULT_ORIGIN

def approve_web_origin(origin: str) -> bool:
    if origin != DEFAULT_ORIGIN: return False
    try:
        helper = helper_path()
        with (helper.parent.parent/'Info.plist').open('rb') as stream:
            if plistlib.load(stream).get('ReleaseHWebControlProtocolVersion') != 1: return False
        if mac_session_unlocked() is not True: return False
        result = subprocess.run([str(helper),'--approve-web-origin',origin],
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, timeout=32, check=False)
        return result.returncode == 0 and mac_session_unlocked() is True
    except subprocess.TimeoutExpired: raise TimeoutError('approval_timeout') from None
    except (OSError, ValueError, subprocess.SubprocessError): return False

def choose_project_folder():
    import json
    helper=helper_path()
    try:
        with (helper.parent.parent/'Info.plist').open('rb') as stream:
            if plistlib.load(stream).get('ReleaseHProjectPickerVersion') != 1:raise ValueError('picker_unavailable')
        if mac_session_unlocked() is not True:raise ValueError('picker_unavailable')
        result=subprocess.run([str(helper),'--choose-project-folder'],stdin=subprocess.DEVNULL,
                              capture_output=True,text=True,timeout=32,check=False)
        if result.returncode or mac_session_unlocked() is not True:raise ValueError('project_not_selected')
        value=json.loads(result.stdout)
        if set(value)!={'path'} or not isinstance(value['path'],str):raise ValueError('project_not_selected')
        return value['path']
    except (OSError,subprocess.SubprocessError,json.JSONDecodeError):raise ValueError('picker_unavailable') from None
