"""Origin-bound local sessions. Nothing in this module is persisted or logged."""
from __future__ import annotations
import hashlib
import secrets
import threading
import time

DEFAULT_ORIGIN = 'http://127.0.0.1:8765'

class ControlError(Exception):
    def __init__(self, status: int, code: str):
        super().__init__(code)
        self.status, self.code = status, code

class SessionStore:
    def __init__(self, *, clock=time.monotonic, approve):
        self.clock, self.approve = clock, approve
        self._lock = threading.RLock()
        self._sessions = {}
        self._last_pair = {}
        self._pending = False
        self._closed = False
        self._epoch = 0
        self.on_revoke = lambda sid: None

    def pair(self, origin: str) -> dict:
        with self._lock:
            now = self.clock()
            if self._closed: raise ControlError(403, 'revoked')
            if self._pending: raise ControlError(409, 'pairing_pending')
            if now - self._last_pair.get(origin, float('-inf')) < 60:
                raise ControlError(429, 'pairing_throttled')
            self._last_pair[origin] = now
            self._pending = True
            epoch = self._epoch
        try:
            try: allowed = self.approve(origin)
            except TimeoutError: raise ControlError(504, 'approval_timeout') from None
            except Exception: raise ControlError(503, 'approval_unavailable') from None
            with self._lock:
                if not allowed or self._closed or epoch != self._epoch: raise ControlError(403, 'approval_denied')
                now = self.clock()
                self._prune(now)
                if len(self._sessions) >= 8: raise ControlError(429, 'session_limit')
                token = secrets.token_urlsafe(32)
                self._sessions[self._key(token)] = [secrets.token_hex(16), origin, now, now]
                return {'token': token, 'expires_in': 28800}
        finally:
            with self._lock: self._pending = False

    @staticmethod
    def _key(token):
        if not isinstance(token, str) or not 40 <= len(token) <= 128:
            raise ControlError(401, 'unauthorized')
        return hashlib.sha256(token.encode()).digest()

    def _prune(self, now):
        for key, session in list(self._sessions.items()):
            if now - session[2] >= 28800 or now - session[3] >= 1800:
                del self._sessions[key]
                self.on_revoke(session[0])

    def authorize(self, token: str, origin: str, *, touch=False) -> str:
        key = self._key(token)
        with self._lock:
            self._prune(self.clock())
            session = self._sessions.get(key)
            if self._closed or not session or session[1] != origin:
                raise ControlError(401, 'unauthorized')
            if touch: session[3] = self.clock()
            return session[0]

    def revoke(self, token: str, origin: str) -> None:
        with self._lock:
            sid = self.authorize(token, origin)
            self._sessions.pop(self._key(token), None)
            self._epoch += 1
            self.on_revoke(sid)

    def perform(self, token, origin, operation, *, touch=True):
        # Admission and revocation are serialized; an accepted action may outlive a session.
        with self._lock:
            sid = self.authorize(token, origin)
            result = operation(sid)
            self.authorize(token, origin, touch=touch)
            return result

    def close(self):
        with self._lock:
            self._closed = True
            sessions, self._sessions = self._sessions, {}
        for session in sessions.values(): self.on_revoke(session[0])
