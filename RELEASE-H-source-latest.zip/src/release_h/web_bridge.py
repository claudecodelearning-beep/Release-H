"""Loopback-only transport for fixed, natively authorized workflow requests."""
import json
import socket
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from .web_control import valid_request_id
from .web_sessions import ControlError, DEFAULT_ORIGIN

BIND = ('127.0.0.1', 8766)
HEALTH = {'product':'release-h-agent','protocol':1,'available':True,'capabilities':['launch-selection']}

def _object(pairs):
    result = {}
    for key,value in pairs:
        if key in result: raise ValueError('duplicate key')
        result[key] = value
    return result

class _BoundedServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    block_on_close = False
    def __init__(self,*args,**kwargs):
        self.slots = threading.BoundedSemaphore(8)
        super().__init__(*args,**kwargs)
    def get_request(self):
        conn,address = super().get_request()
        conn.settimeout(5)
        return conn,address
    def process_request(self, request, address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request); return
        try: super().process_request(request,address)
        except Exception:
            self.slots.release(); self.shutdown_request(request)
    def process_request_thread(self, request, address):
        try: super().process_request_thread(request,address)
        finally: self.slots.release()
    def handle_error(self,*args): pass

class LocalControlServer:
    def __init__(self,sessions,control,*,origins=frozenset({DEFAULT_ORIGIN})):
        # Public origins are intentionally not configurable by network callers.
        if origins != frozenset({DEFAULT_ORIGIN}): raise ValueError('Only the local preview origin is enabled')
        self.sessions,self.control,self.origins = sessions,control,origins
        self.sessions.on_revoke = self.control.forget_session
        self._server = None
        self._thread = None
        self._picker_lock = threading.Lock()

    @property
    def address(self): return self._server.server_address

    def start(self):
        owner = self
        class Handler(BaseHTTPRequestHandler):
            server_version = 'RELEASEH'
            sys_version = ''
            def log_message(self,*args): pass
            def send_error(self,code,message=None,explain=None):
                self._respond(code,{'error':'invalid_request'})
            def _respond(self,status,payload=None,headers=None):
                encoded=json.dumps(payload,separators=(',',':')).encode() if payload is not None else b''
                self.send_response(status)
                self.send_header('Content-Type','application/json')
                self.send_header('Content-Length',str(len(encoded)))
                self.send_header('Cache-Control','no-store')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Vary','Origin')
                if getattr(self,'allowed',False): self.send_header('Access-Control-Allow-Origin',self.headers['Origin'])
                for key,value in (headers or {}).items(): self.send_header(key,value)
                self.end_headers()
                if encoded and self.command != 'HEAD': self.wfile.write(encoded)
                self.close_connection = True
            def _validate(self):
                self.allowed = False
                for name in ('Host','Origin','Authorization','Content-Length','Content-Type','Transfer-Encoding'):
                    if len(self.headers.get_all(name,[])) > 1: raise ControlError(400,'invalid_request')
                expected=f'127.0.0.1:{self.server.server_address[1]}'
                if self.client_address[0] != '127.0.0.1' or self.headers.get('Host') != expected:
                    raise ControlError(403,'forbidden')
                if self.headers.get('Origin') not in owner.origins: raise ControlError(403,'forbidden')
                self.allowed = True
                if self.headers.get('Transfer-Encoding'): raise ControlError(400,'invalid_request')
            def _json(self):
                if self.headers.get('Content-Type','').split(';')[0].strip().lower() != 'application/json':
                    raise ControlError(415,'json_required')
                length=self.headers.get('Content-Length','')
                if not length.isascii() or not length.isdigit(): raise ControlError(400,'invalid_request')
                if int(length)>4096: raise ControlError(413,'request_too_large')
                raw=self.rfile.read(int(length))
                if len(raw) != int(length): raise ControlError(400,'invalid_request')
                try: result=json.loads(raw,object_pairs_hook=_object)
                except (ValueError,UnicodeError): raise ControlError(400,'invalid_request') from None
                if not isinstance(result,dict): raise ControlError(400,'invalid_request')
                return result
            def _token(self):
                authorization=self.headers.get('Authorization','')
                if not authorization.startswith('Bearer '): raise ControlError(401,'unauthorized')
                return authorization[7:]
            def _dispatch(self):
                try:
                    self._validate()
                    origin=self.headers['Origin']
                    if self.command == 'OPTIONS':
                        if self.path not in ('/v1/session','/v1/health','/v1/start','/v1/selection','/v1/project') and not self.path.startswith('/v1/requests/'):
                            raise ControlError(404,'not_found')
                        if self.headers.get('Access-Control-Request-Method') not in ('GET','POST','DELETE'):
                            raise ControlError(403,'forbidden')
                        requested={h.strip().lower() for h in self.headers.get('Access-Control-Request-Headers','').split(',') if h.strip()}
                        if requested - {'authorization','content-type'}: raise ControlError(403,'forbidden')
                        return self._respond(204,headers={'Access-Control-Allow-Methods':'GET, POST, DELETE',
                            'Access-Control-Allow-Headers':'Authorization, Content-Type'})
                    if self.command == 'GET' and self.path == '/v1/health': return self._respond(200,HEALTH)
                    if self.path == '/v1/selection' and self.command in ('GET','POST'):
                        token=self._token()
                        owner.sessions.authorize(token,origin)
                        try:
                            selection=self._json() if self.command == 'POST' else None
                            result=owner.sessions.perform(token,origin,lambda sid:owner.control.save_selection(selection) if self.command=='POST' else owner.control.get_selection(),touch=False)
                            return self._respond(200,result)
                        except ValueError as error:raise ControlError(400,str(error)) from None
                    if self.path == '/v1/project' and self.command == 'POST':
                        token=self._token();owner.sessions.authorize(token,origin)
                        if self._json() != {}:raise ControlError(400,'invalid_request')
                        if not owner._picker_lock.acquire(blocking=False):raise ControlError(409,'picker_busy')
                        try:
                            from .web_approval import choose_project_folder
                            folder=choose_project_folder()
                            owner.sessions.perform(token,origin,lambda sid:owner.control.set_project(folder),touch=False)
                            return self._respond(200,{'project_configured':True})
                        except ValueError as error:raise ControlError(400,str(error)) from None
                        finally:owner._picker_lock.release()
                    if self.command == 'POST' and self.path == '/v1/session':
                        if self._json() != {}: raise ControlError(400,'invalid_request')
                        return self._respond(201,owner.sessions.pair(origin))
                    if self.command == 'DELETE' and self.path == '/v1/session':
                        owner.sessions.revoke(self._token(),origin)
                        return self._respond(204)
                    if self.command == 'POST' and self.path == '/v1/start':
                        data=self._json()
                        if set(data) not in ({'action','request_id'},{'action','request_id','selection'}) or data.get('action') != 'start-work' or not valid_request_id(data.get('request_id')):
                            raise ControlError(400,'invalid_request')
                        result=owner.sessions.perform(self._token(),origin,lambda sid: owner.control.submit(sid,data['request_id'],data.get('selection')))
                        return self._respond(202,result)
                    if self.command == 'GET' and self.path.startswith('/v1/requests/'):
                        ident=self.path[len('/v1/requests/'):]
                        if not valid_request_id(ident): raise ControlError(404,'request_unknown')
                        sid=owner.sessions.authorize(self._token(),origin)
                        return self._respond(200,owner.control.read(sid,ident))
                    raise ControlError(404,'not_found')
                except ControlError as error: self._respond(error.status,{'error':error.code})
                except (BrokenPipeError,ConnectionError,socket.timeout): pass
                except Exception: self._respond(503,{'error':'unavailable'})
            do_GET=do_POST=do_DELETE=do_OPTIONS=_dispatch
            def _unsupported(self): self._respond(405,{'error':'method_not_allowed'},{'Allow':'GET, POST, DELETE, OPTIONS'})
            do_PUT=do_PATCH=do_HEAD=_unsupported
        self._server=_BoundedServer(BIND,Handler)
        self._thread=threading.Thread(target=self._server.serve_forever,kwargs={'poll_interval':0.05},daemon=True)
        self._thread.start()

    def close(self):
        self.sessions.close()
        if self._server:
            self._server.shutdown(); self._server.server_close()
        if self._thread: self._thread.join(2)
