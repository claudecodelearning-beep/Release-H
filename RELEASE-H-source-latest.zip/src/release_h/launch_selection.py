"""User-selected launch targets, persisted only in the private runtime directory."""
import hashlib
import ipaddress
import json
import subprocess
from pathlib import Path
from urllib.parse import urlsplit
from .agent_queue import _atomic_json_write

APPS={
 'vscode':('Visual Studio Code','com.microsoft.VSCode'),
 'terminal':('Terminal','com.apple.Terminal'), 'notes':('Notes','com.apple.Notes'),
 'codex':('Codex','com.openai.codex'), 'claude':('Claude','com.anthropic.claudefordesktop'),
 'chrome':('Google Chrome','com.google.Chrome'), 'safari':('Safari','com.apple.Safari'),
 'music':('Music','com.apple.Music'), 'cursor':('Cursor','com.todesktop.230313mzl4w4u92'),
 'pycharm':('PyCharm','com.jetbrains.pycharm'), 'calendar':('Calendar','com.apple.iCal'),
 'reminders':('Reminders','com.apple.reminders')}

def validate_selection(value):
    if not isinstance(value,dict) or set(value)!={'apps','websites','project'}:raise ValueError('invalid_selection')
    apps,sites,project=value['apps'],value['websites'],value['project']
    if not isinstance(apps,list) or len(apps)>len(APPS) or any(not isinstance(a,str) or a not in APPS for a in apps) or len(set(apps))!=len(apps):raise ValueError('invalid_apps')
    if not isinstance(sites,list) or len(sites)>5 or type(project) is not bool:raise ValueError('invalid_selection')
    for site in sites:
        if not isinstance(site,str) or len(site)>512 or any(ord(c)<=32 or ord(c)==127 for c in site) or '\\' in site:raise ValueError('invalid_website')
        try:
            url=urlsplit(site)
            host=url.hostname.rstrip('.').lower() if url.hostname else None
            if url.scheme not in ('https','http') or not host or url.username is not None or url.password is not None or url.port not in (None,80,443):raise ValueError('invalid_website')
            if '.' not in host or host.endswith(('.localhost','.local','.internal')) or host in ('localhost','localhost.localdomain'):raise ValueError('invalid_website')
            try:address=ipaddress.ip_address(host)
            except ValueError:address=None
            last=host.rsplit('.',1)[-1]
            if address is None and (last.isdigit() or last.startswith('0x')):raise ValueError('invalid_website')
            if address and not address.is_global:raise ValueError('invalid_website')
        except (ValueError,TypeError):raise ValueError('invalid_website') from None
    return {'apps':apps.copy(),'websites':sites.copy(),'project':project}

class SelectionStore:
    def __init__(self,root):self.root=Path(root);self.path=self.root/'launch-preferences.json'
    def _load(self):
        if not self.path.exists():return {'selection':{'apps':[],'websites':[],'project':False},'project_path':None}
        return json.loads(self.path.read_text())
    def public(self):
        saved=self._load()
        return {'apps':[{'id':key,'label':label} for key,(label,_) in APPS.items()],
                'selection':validate_selection(saved['selection']), 'project_configured':bool(saved.get('project_path'))}
    def set_project(self,path):
        folder=Path(path)
        if not folder.is_absolute() or not folder.is_dir():raise ValueError('invalid_project')
        saved=self._load();saved['project_path']=str(folder.resolve());_atomic_json_write(self.path,saved)
    def save(self,selection):
        checked=self.snapshot(selection)['selection'];saved=self._load();saved['selection']=checked;_atomic_json_write(self.path,saved)
    def snapshot(self,selection):
        checked=validate_selection(selection);folder=self._load().get('project_path') if checked['project'] else None
        if checked['project'] and (not folder or not Path(folder).is_dir()):raise ValueError('project_required')
        if not checked['apps'] and not checked['websites'] and not checked['project']:raise ValueError('empty_selection')
        return {'selection':checked,'project_path':folder}
    def request_path(self,request_id):return self.root/'launch-requests'/(hashlib.sha256(request_id.encode()).hexdigest()+'.json')

def execute_selection(snapshot,*,run=subprocess.run):
    from .agent import ExecutionResult,_now
    started=_now();failed=False
    try:
        selection=validate_selection(snapshot['selection']);commands=[]
        for app in selection['apps']:
            if app=='pycharm' and selection['project']:continue
            commands.append(['/usr/bin/open','-b',APPS[app][1]])
        commands.extend([['/usr/bin/open',site] for site in selection['websites']])
        if selection['project']:
            folder=snapshot.get('project_path')
            if not isinstance(folder,str) or not Path(folder).is_absolute() or not Path(folder).is_dir():raise ValueError('invalid_project')
            commands.append(['/usr/bin/open','-b',APPS['pycharm'][1],folder])
        for command in commands:
            try:
                if run(command,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15,check=False).returncode:failed=True
            except (OSError,subprocess.SubprocessError):failed=True
    except (ValueError,KeyError,TypeError):failed=True
    return ExecutionResult(1 if failed else 0,'','','' if not started else started,_now())
