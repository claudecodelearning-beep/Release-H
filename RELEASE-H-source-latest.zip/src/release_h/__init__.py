"""RELEASE H local work-mode automation."""

__version__ = "0.2.0"
