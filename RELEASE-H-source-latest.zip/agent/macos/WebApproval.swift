import AppKit
import Foundation

func unlockedForApproval() -> Bool {
    let probe = Process()
    let pipe = Pipe()
    probe.executableURL = URL(fileURLWithPath: "/usr/sbin/ioreg")
    probe.arguments = ["-n", "Root", "-d", "1", "-w", "0"]
    probe.standardOutput = pipe
    probe.standardError = FileHandle.nullDevice
    do { try probe.run() } catch { return false }
    let output = pipe.fileHandleForReading.readDataToEndOfFile()
    probe.waitUntilExit()
    guard probe.terminationStatus == 0, let value = String(data: output, encoding: .utf8) else { return false }
    return value.contains("\"kCGSSessionOnConsoleKey\"=Yes") &&
        value.contains("\"kCGSessionLoginDoneKey\"=Yes") &&
        !value.contains("\"CGSSessionScreenIsLocked\"=Yes")
}

func runWebApproval(origin: String) -> Never {
    guard origin == "http://127.0.0.1:8765", unlockedForApproval() else { exit(1) }
    let app = NSApplication.shared
    app.setActivationPolicy(.accessory)
    app.activate(ignoringOtherApps: true)
    let alert = NSAlert()
    alert.alertStyle = .warning
    alert.messageText = "Allow RELEASE H workflow control?"
    alert.informativeText = "Website: \(origin)\n\nAllow this website to start your configured workflow during this session? This can open apps, move windows and press configured Bots, including while the desktop is locked.\n\nOnly approve a page you trust. The session expires after 30 minutes without a start request, or after 8 hours. Disconnect revokes future requests; accepted work can continue."
    alert.addButton(withTitle: "Deny").keyEquivalent = "\r"
    alert.addButton(withTitle: "Allow for this session").keyEquivalent = ""
    let timer = Timer(timeInterval: 0.5, repeats: true) { _ in
        if !unlockedForApproval() { exit(1) }
    }
    RunLoop.main.add(timer, forMode: .common)
    // The independent process deadline also applies if the modal runloop stalls.
    DispatchQueue.global().asyncAfter(deadline: .now() + 30) { exit(1) }
    let answer = alert.runModal()
    timer.invalidate()
    exit(answer == .alertSecondButtonReturn && unlockedForApproval() ? 0 : 1)
}
