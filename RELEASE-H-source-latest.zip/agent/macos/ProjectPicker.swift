import AppKit
import Foundation

func runProjectPicker() -> Never {
    guard unlockedForApproval() else { exit(1) }
    NSApplication.shared.setActivationPolicy(.accessory)
    NSApplication.shared.activate(ignoringOtherApps: true)
    let panel = NSOpenPanel()
    panel.title = "RELEASE H — Choose your PyCharm project"
    panel.message = "Choose a project folder for http://127.0.0.1:8765. The path stays on this Mac."
    panel.canChooseDirectories = true
    panel.canChooseFiles = false
    panel.allowsMultipleSelection = false
    panel.prompt = "Use this project"
    DispatchQueue.global().asyncAfter(deadline: .now() + 30) { exit(1) }
    guard panel.runModal() == .OK, unlockedForApproval(), let url = panel.url,
          let data = try? JSONSerialization.data(withJSONObject: ["path": url.path]) else { exit(1) }
    FileHandle.standardOutput.write(data)
    exit(0)
}
