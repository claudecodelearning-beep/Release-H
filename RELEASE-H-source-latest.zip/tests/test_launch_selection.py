import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from release_h.launch_selection import validate_selection, SelectionStore, execute_selection

class SelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.store=SelectionStore(self.root)
    def test_rejects_executable_input_and_unsafe_urls(self):
        for value in ({'apps':['sh'],'websites':[],'project':False},
                      {'apps':[],'websites':['file:///etc/passwd'],'project':False},
                      {'apps':[],'websites':['https://user:pass@example.com'],'project':False},
                      {'apps':[],'websites':['http://127.0.0.1:8080'],'project':False},
                      {'apps':[],'websites':['http://127.1'],'project':False},
                      {'apps':[],'websites':['http://0x7f.0.0.1'],'project':False},
                      {'apps':[],'websites':['http://localhost./'],'project':False},
                      {'apps':[],'websites':[],'project':False,'command':'bad'}):
            with self.assertRaises(ValueError):validate_selection(value)
    def test_saved_settings_are_private_and_folder_path_never_in_public_profile(self):
        self.store.set_project(str(self.root))
        value={'apps':['music','cursor'],'websites':['https://example.com'],'project':True}
        self.store.save(value)
        self.assertEqual(self.store.public()['selection'],value)
        self.assertNotIn(str(self.root),str(self.store.public()))
        self.assertEqual((self.root/'launch-preferences.json').stat().st_mode & 0o777,0o600)
    def test_execution_uses_fixed_bundle_ids_and_no_shell(self):
        self.store.set_project(str(self.root));calls=[]
        def run(args,**kw):calls.append((args,kw));return SimpleNamespace(returncode=0)
        selection={'apps':['music','cursor'],'websites':['https://example.com'],'project':True}
        snapshot=self.store.snapshot(selection)
        result=execute_selection(snapshot,run=run)
        self.assertEqual(result.exit_code,0)
        self.assertEqual(calls[0][0],['/usr/bin/open','-b','com.apple.Music'])
        self.assertEqual(calls[1][0],['/usr/bin/open','-b','com.todesktop.230313mzl4w4u92'])
        self.assertEqual(calls[-1][0],['/usr/bin/open','-b','com.jetbrains.pycharm',str(self.root.resolve())])
        self.assertTrue(all(not kwargs.get('shell',False) for _,kwargs in calls))
    def test_missing_project_and_duplicate_apps_rejected(self):
        with self.assertRaises(ValueError):self.store.snapshot({'apps':[],'websites':[],'project':True})
        with self.assertRaises(ValueError):validate_selection({'apps':['music','music'],'websites':[],'project':False})

    def test_selected_launch_does_not_execute_legacy_workflow_or_hardware(self):
        from unittest.mock import patch
        from release_h.agent import Agent
        from release_h.agent_queue import QueuePaths
        from release_h.web_control import ControlState
        import uuid
        paths=QueuePaths.at(self.root);control=ControlState(paths)
        control.submit('session',str(uuid.uuid4()),{'apps':['music'],'websites':[],'project':False})
        calls=[]
        def forbidden(*args):raise AssertionError('legacy workflow/hardware invoked')
        with patch('release_h.launch_selection.subprocess.run',side_effect=lambda *a,**kw:calls.append(a) or SimpleNamespace(returncode=0)):
            # Default run injection is explicit, so replace only the selection executor.
            with patch('release_h.launch_selection.execute_selection',side_effect=lambda snap:execute_selection(snap,run=lambda *a,**kw:calls.append(a) or SimpleNamespace(returncode=0))):
                self.assertEqual(Agent(paths,lambda:True,forbidden,forbidden).run_once().status,'completed')
        self.assertEqual(len(calls),1)

    def test_missing_selection_snapshot_never_falls_back_to_bot_workflow(self):
        from release_h.agent import Agent
        from release_h.agent_queue import QueuePaths,load_request
        from release_h.web_control import ControlState
        import uuid
        paths=QueuePaths.at(self.root);control=ControlState(paths)
        control.submit('session',str(uuid.uuid4()),{'apps':['music'],'websites':[],'project':False})
        self.store.request_path(load_request(paths.pending).request_id).unlink()
        calls=[]
        def forbidden(*args):calls.append('legacy');raise AssertionError('forbidden')
        self.assertEqual(Agent(paths,lambda:True,forbidden,forbidden).run_once().status,'failed')
        self.assertEqual(calls,[])
