import threading
import unittest
from release_h.web_sessions import SessionStore, ControlError

ORIGIN = 'http://127.0.0.1:8765'

class SessionTests(unittest.TestCase):
    def setUp(self):
        self.now = 0
        self.store = SessionStore(clock=lambda: self.now, approve=lambda origin: True)

    def test_origin_bound_ephemeral_and_revocable(self):
        first = self.store.pair(ORIGIN)
        token = first['token']
        self.assertGreaterEqual(len(token), 40)
        sid = self.store.authorize(token, ORIGIN)
        self.assertNotEqual(sid, token)
        with self.assertRaises(ControlError): self.store.authorize(token, 'https://evil.example')
        self.store.revoke(token, ORIGIN)
        with self.assertRaises(ControlError): self.store.authorize(token, ORIGIN)

    def test_polling_does_not_extend_idle_expiry(self):
        token = self.store.pair(ORIGIN)['token']
        self.now = 1799
        self.store.authorize(token, ORIGIN)
        self.now = 1800
        with self.assertRaises(ControlError): self.store.authorize(token, ORIGIN)

    def test_activity_has_hard_eight_hour_limit(self):
        token = self.store.pair(ORIGIN)['token']
        for self.now in range(1000, 28001, 1000): self.store.authorize(token, ORIGIN, touch=True)
        self.now = 28800
        with self.assertRaises(ControlError): self.store.authorize(token, ORIGIN)

    def test_denied_and_rate_limited_pairing_never_grants_token(self):
        store = SessionStore(clock=lambda: self.now, approve=lambda origin: False)
        with self.assertRaises(ControlError) as denied: store.pair(ORIGIN)
        self.assertEqual(denied.exception.status, 403)
        with self.assertRaises(ControlError) as limited: store.pair(ORIGIN)
        self.assertEqual(limited.exception.status, 429)

    def test_close_invalidates_in_flight_approval(self):
        entered, release = threading.Event(), threading.Event()
        def approve(origin): entered.set(); release.wait(2); return True
        store = SessionStore(approve=approve)
        errors = []
        def pair():
            try: store.pair(ORIGIN)
            except ControlError as error: errors.append(error.status)
        thread = threading.Thread(target=pair); thread.start(); entered.wait(2)
        with self.assertRaises(ControlError): store.pair(ORIGIN)
        store.close(); release.set(); thread.join(2)
        self.assertEqual(errors, [403])

    def test_pairing_timeout_and_unexpected_errors_are_sanitized(self):
        def fail(origin): raise TimeoutError('PRIVATE SENTINEL')
        with self.assertRaises(ControlError) as error: SessionStore(approve=fail).pair(ORIGIN)
        self.assertEqual(error.exception.status, 504)
        self.assertNotIn('PRIVATE', str(error.exception))

    def test_revoke_invalidates_a_pending_approval_for_same_origin(self):
        token=self.store.pair(ORIGIN)['token'];self.now=61
        entered, release=threading.Event(),threading.Event()
        self.store.approve=lambda origin: (entered.set(),release.wait(2),True)[2]
        errors=[]
        def pair():
            try: self.store.pair(ORIGIN)
            except ControlError as error: errors.append(error.status)
        thread=threading.Thread(target=pair);thread.start();entered.wait(2)
        self.store.revoke(token,ORIGIN);release.set();thread.join(2)
        self.assertEqual(errors,[403])
