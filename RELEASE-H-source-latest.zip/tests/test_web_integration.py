"""Real local HTTP and queue; no native UI, device access or desktop automation."""
import json
import multiprocessing
import os
import threading
import time
import unittest
import uuid
from unittest.mock import patch
from release_h.agent import Agent, ExecutionEvent, ExecutionResult
from release_h.agent_queue import QueueBusy, enqueue_start
from release_h.cli import main
from tests.test_web_bridge import BridgeTests, ORIGIN

def enqueue_competitor(root, output):
    from pathlib import Path
    from release_h.agent_queue import QueuePaths, enqueue_start, QueueBusy
    try: enqueue_start(QueuePaths.at(Path(root)),'process-request',reject_if_busy=True); output.put('ok')
    except QueueBusy: output.put('busy')

class IntegrationTests(BridgeTests):
    def test_http_to_locked_agent_to_completion_never_leaks_private_output(self):
        token=self.pair(); ident=str(uuid.uuid4())
        self.request('POST','/v1/start',{'action':'start-work','request_id':ident},token)
        unlocked=[False]; attempts=set(); actual_actions=[]
        def hardware(request_id):
            if request_id not in attempts: attempts.add(request_id); actual_actions.append(request_id)
            return []
        agent=Agent(self.control.paths,lambda:unlocked[0],lambda:ExecutionResult(0,'PRIVATE_SENTINEL','SECRET','',''),hardware,on_event=self.control.observe)
        for _ in range(3): agent.run_once()
        self.assertEqual(self.request('GET','/v1/requests/'+ident,token=token)[1]['status'],'waiting_unlock')
        unlocked[0]=True;agent.run_once()
        status,body,_=self.request('GET','/v1/requests/'+ident,token=token)
        self.assertEqual(body,{'request_id':ident,'status':'completed'})
        self.assertEqual(len(actual_actions),1)
        self.assertNotIn('PRIVATE',json.dumps(body))

    def test_lost_response_replay_and_cross_session_status_isolation(self):
        token=self.pair(); ident=str(uuid.uuid4()); data={'action':'start-work','request_id':ident}
        self.request('POST','/v1/start',data,token)
        self.assertEqual(self.request('POST','/v1/start',data,token)[1]['status'],'queued')
        # A second native-approved session cannot inspect another tab's request.
        with patch.object(self.sessions,'clock',return_value=time.monotonic()+61):
            other=self.pair()
        self.assertEqual(self.request('GET','/v1/requests/'+ident,token=other)[0],404)
        self.assertEqual(self.request('POST','/v1/start',data,other)[0],404)
        self.request('DELETE','/v1/session',token=token)
        self.assertEqual(self.request('GET','/v1/requests/'+ident,token=token)[0],401)
        self.assertTrue(self.control.paths.pending.exists())  # Revoke does not cancel accepted work.

    def test_cross_process_admission_cannot_replace_pending_web_work(self):
        token=self.pair();ident=str(uuid.uuid4())
        self.request('POST','/v1/start',{'action':'start-work','request_id':ident},token)
        ctx=multiprocessing.get_context('spawn');out=ctx.Queue()
        process=ctx.Process(target=enqueue_competitor,args=(str(self.control.paths.root),out));process.start();process.join(5)
        self.assertEqual(process.exitcode,0);self.assertEqual(out.get(timeout=1),'busy');out.close()

    def test_callback_failure_does_not_repeat_execution(self):
        enqueue_start(self.control.paths,'ordinary')
        executions=[]
        def broken(event): raise RuntimeError('PRIVATE')
        agent=Agent(self.control.paths,lambda:True,lambda:executions.append(1) or ExecutionResult(0,'','','',''),on_event=broken)
        agent.run_once();agent.run_once();self.assertEqual(executions,[1])

    def test_bridge_closes_when_cli_loop_exits(self):
        # Use a separate temp runtime; all real workflow execution is replaced.
        with patch.dict(os.environ,{'RELEASE_H_RUNTIME_DIR':str(self.control.paths.root)}),\
             patch('release_h.web_bridge.BIND',('127.0.0.1',0)),\
             patch('release_h.cli.run_forever',return_value=None),\
             patch('release_h.web_bridge.LocalControlServer.close',autospec=True) as close:
            self.assertEqual(main(['agent','--web-control']),0)
            created=close.call_args.args[0]
        created.close()
        self.assertEqual(len(close.call_args_list),1)

    def test_cli_busy_does_not_overwrite_authorized_request(self):
        import contextlib,io
        token=self.pair();ident=str(uuid.uuid4())
        self.request('POST','/v1/start',{'action':'start-work','request_id':ident},token)
        with patch.dict(os.environ,{'RELEASE_H_RUNTIME_DIR':str(self.control.paths.root)}),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main(['request-start','--json']),1)
        self.assertEqual(json.loads(self.control.paths.pending.read_text())['request_id'],'web:'+ident)
