import contextlib
import http.client
import io
import json
import tempfile
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch
from release_h.agent_queue import QueuePaths
from release_h.web_control import ControlState
from release_h.web_sessions import SessionStore
from release_h.web_bridge import LocalControlServer

ORIGIN='http://127.0.0.1:8765'

class BridgeTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory(); self.addCleanup(temp.cleanup)
        self.control=ControlState(QueuePaths.at(Path(temp.name)))
        self.sessions=SessionStore(approve=lambda origin:True)
        with patch('release_h.web_bridge.BIND', ('127.0.0.1',0)):
            self.server=LocalControlServer(self.sessions,self.control,origins=frozenset({ORIGIN}))
            self.server.start()
        self.addCleanup(self.server.close)
        self.port=self.server.address[1]

    def request(self, method, path, data=None, token=None, origin=ORIGIN, headers=None):
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
        self.addCleanup(conn.close)
        values={'Origin':origin,'Content-Type':'application/json'}
        if token: values['Authorization']='Bearer '+token
        values.update(headers or {})
        conn.request(method,path, json.dumps(data) if data is not None else None,values)
        result=conn.getresponse(); body=result.read()
        return result.status,json.loads(body) if body else None,dict(result.getheaders())

    def pair(self): return self.request('POST','/v1/session',{})[1]['token']

    def test_authorized_start_is_queued_and_replayed_once(self):
        token=self.pair(); ident=str(uuid.uuid4())
        data={'action':'start-work','request_id':ident}
        self.assertEqual(self.request('POST','/v1/start',data)[0],401)
        for _ in range(2):
            status,body,headers=self.request('POST','/v1/start',data,token)
            self.assertEqual((status,body['status']),(202,'queued'))
            self.assertEqual(headers['Cache-Control'],'no-store')
        self.assertEqual(self.request('GET','/v1/requests/'+ident,token=token)[1],{'request_id':ident,'status':'queued'})
        self.assertEqual(self.request('DELETE','/v1/session',token=token)[0],204)
        self.assertEqual(self.request('POST','/v1/start',data,token)[0],401)

    def test_host_origin_and_preflight_are_checked(self):
        for origin in ('null','https://evil.example',''):
            self.assertEqual(self.request('GET','/v1/health',origin=origin)[0],403)
        self.assertEqual(self.request('GET','/v1/health',headers={'Host':'evil.example'})[0],403)
        status,body,headers=self.request('OPTIONS','/v1/start',headers={'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'authorization, content-type'})
        self.assertEqual(status,204)
        self.assertEqual(headers['Access-Control-Allow-Origin'],ORIGIN)
        self.assertNotIn('Access-Control-Allow-Credentials',headers)

    def test_input_validation_cannot_enqueue_or_expose_secrets(self):
        token=self.pair(); ident=str(uuid.uuid4())
        for data in ({'action':'shell','request_id':ident},{'action':'start-work','request_id':ident,'path':'PRIVATE'},{'action':'start-work','request_id':'bad'}):
            self.assertEqual(self.request('POST','/v1/start',data,token)[0],400)
        self.assertEqual(self.request('POST','/v1/session',{},headers={'Content-Type':'text/plain'})[0],415)
        self.assertEqual(self.request('POST','/v1/start',{'padding':'a'*8192},token)[0],413)
        self.assertFalse(self.control.paths.pending.exists())
        self.assertEqual(self.request('GET','/v1/health')[1],{'product':'release-h-agent','protocol':1,'available':True,'capabilities':['launch-selection']})

    def test_selection_profile_is_authenticated_and_project_path_stays_local(self):
        self.assertEqual(self.request('GET','/v1/selection')[0],401)
        token=self.pair()
        profile={'apps':['cursor','music'],'websites':['https://example.com'],'project':False}
        self.assertEqual(self.request('POST','/v1/selection',profile,token)[1]['selection'],profile)
        with patch('release_h.web_approval.choose_project_folder',return_value=str(self.control.paths.root)):
            self.assertEqual(self.request('POST','/v1/project',{},token)[1],{'project_configured':True})
        self.assertNotIn(str(self.control.paths.root),json.dumps(self.request('GET','/v1/selection',token=token)[1]))
        ident=str(uuid.uuid4())
        self.assertEqual(self.request('POST','/v1/start',{'action':'start-work','request_id':ident,'selection':profile},token)[0],202)
        self.assertEqual(self.request('GET','/runtime/switchbot.json',token=token)[0],404)

    def test_duplicate_security_headers_and_duplicate_json_keys_are_rejected(self):
        for duplicate in ('Host','Origin','Authorization','Content-Length'):
            conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
            conn.putrequest('POST','/v1/session',skip_host=True)
            conn.putheader('Host',f'127.0.0.1:{self.port}')
            conn.putheader('Origin',ORIGIN); conn.putheader('Content-Type','application/json')
            conn.putheader('Content-Length','2')
            if duplicate == 'Authorization': conn.putheader('Authorization','Bearer first')
            conn.putheader(duplicate,'bad'); conn.endheaders(b'{}')
            result=conn.getresponse(); self.assertIn(result.status,(400,403)); result.read(); conn.close()
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
        conn.request('POST','/v1/session',b'{"a":1,"a":2}',{'Origin':ORIGIN,'Content-Type':'application/json'})
        result=conn.getresponse(); self.assertEqual(result.status,400); result.read(); conn.close()

    def test_no_request_or_secret_logging(self):
        output=io.StringIO()
        with contextlib.redirect_stderr(output):
            self.request('POST','/v1/start',{'secret':'PRIVATE-SENTINEL'},'not-a-valid-token')
        self.assertEqual(output.getvalue(),'')
