"""Manual UI QA only: simulated consent and executors, temporary queue, no devices."""
import tempfile
import time
from pathlib import Path
from release_h.agent import Agent, ExecutionResult
from release_h.agent_queue import QueuePaths
from release_h.web_bridge import LocalControlServer
from release_h.web_control import ControlState
from release_h.web_sessions import SessionStore

def main():
    with tempfile.TemporaryDirectory(prefix='release-h-ui-fake-') as temporary:
        paths=QueuePaths.at(Path(temporary));control=ControlState(paths)
        sessions=SessionStore(approve=lambda origin:True)
        bridge=LocalControlServer(sessions,control)
        began=[None]
        def hardware(request_id):
            if began[0] is None: began[0]=time.monotonic()
            return []
        def desktop():
            time.sleep(3)
            return ExecutionResult(0,'FAKE-ONLY','','','')
        agent=Agent(paths,lambda:began[0] is not None and time.monotonic()-began[0]>7,desktop,hardware,on_event=control.observe)
        bridge.start()
        print('SIMULATED UI QA AGENT ONLY: no native consent, no desktop access, no physical devices',flush=True)
        try:
            while True: agent.run_once();time.sleep(0.2)
        except KeyboardInterrupt: pass
        finally: bridge.close()

if __name__=='__main__': main()
