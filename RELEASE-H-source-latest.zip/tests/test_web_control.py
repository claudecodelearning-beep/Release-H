import json
import tempfile
import threading
import unittest
import uuid
from pathlib import Path
from release_h.agent import Agent, ExecutionResult
from release_h.agent_queue import QueuePaths, enqueue_start, QueueBusy
from release_h.web_control import ControlState
from release_h.web_sessions import ControlError

class ControlTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(); self.addCleanup(temp.cleanup)
        self.paths = QueuePaths.at(Path(temp.name)); self.control = ControlState(self.paths)
        self.ident = str(uuid.uuid4())

    def test_replay_and_cross_session_ownership(self):
        self.assertEqual(self.control.submit('one', self.ident)['status'], 'queued')
        self.assertEqual(self.control.submit('one', self.ident)['status'], 'queued')
        with self.assertRaises(ControlError): self.control.read('two', self.ident)
        with self.assertRaises(ControlError): self.control.submit('two', self.ident)
        with self.assertRaises(QueueBusy): enqueue_start(self.paths, 'legacy')

    def test_two_concurrent_requests_admit_only_one(self):
        outcomes = []
        def submit():
            try: self.control.submit('one', str(uuid.uuid4())); outcomes.append('ok')
            except ControlError: outcomes.append('busy')
        threads = [threading.Thread(target=submit) for _ in range(2)]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        self.assertCountEqual(outcomes, ['ok','busy'])

    def test_real_events_are_sanitized_and_locked_state_is_retained(self):
        self.control.submit('one', self.ident)
        unlocked = [False]
        hardware = []
        def execute(): return ExecutionResult(0, 'PRIVATE-SENTINEL', 'SECRET', '', '')
        agent = Agent(self.paths, session_unlocked=lambda: unlocked[0], execute_workflow=execute,
                      execute_hardware=lambda req: hardware.append(req) or [], on_event=self.control.observe)
        agent.run_once()
        self.assertEqual(self.control.read('one',self.ident)['status'], 'waiting_unlock')
        unlocked[0] = True; agent.run_once()
        result = self.control.read('one',self.ident)
        self.assertEqual(result, {'request_id':self.ident,'status':'completed'})
        self.assertNotIn('PRIVATE', json.dumps(result))

    def test_hardware_failure_is_not_success(self):
        self.control.submit('one',self.ident)
        Agent(self.paths, lambda:True, lambda:ExecutionResult(0,'','','',''),
              lambda req:[{'status':'failed','detail':'PRIVATE'}], on_event=self.control.observe).run_once()
        self.assertEqual(self.control.read('one',self.ident)['status'],'failed')

    def test_bad_ids_and_busy_legacy_queue(self):
        with self.assertRaises(ControlError): self.control.submit('one','../../bad')
        enqueue_start(self.paths,'legacy')
        with self.assertRaises(ControlError): self.control.submit('one',self.ident)

    def test_tampered_queue_reports_unknown_instead_of_polling_forever(self):
        self.control.submit('one',self.ident)
        self.paths.pending.write_text('corrupt PRIVATE_SENTINEL')
        executed=[]
        outcome=Agent(self.paths,lambda:True,lambda:executed.append(1),on_event=self.control.observe).run_once()
        self.assertEqual(outcome.status,'invalid')
        self.assertEqual(executed,[])
        self.assertEqual(self.control.read('one',self.ident),{'request_id':self.ident,'status':'unknown'})
