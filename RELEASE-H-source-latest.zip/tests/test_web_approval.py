import plistlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from release_h.web_approval import approve_web_origin

class ApprovalTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory(); self.addCleanup(temp.cleanup)
        self.contents=Path(temp.name)/'Contents'; (self.contents/'MacOS').mkdir(parents=True)
        self.helper=self.contents/'MacOS'/'ReleaseHAgent'
    def marker(self,value):
        (self.contents/'Info.plist').write_bytes(plistlib.dumps({'ReleaseHWebControlProtocolVersion':value}))
    def test_old_binary_never_spawns(self):
        self.marker(0)
        with patch('release_h.web_approval.helper_path',return_value=self.helper), patch('release_h.web_approval.subprocess.run') as run:
            self.assertFalse(approve_web_origin('http://127.0.0.1:8765')); run.assert_not_called()
    def test_locked_state_never_prompts(self):
        self.marker(1)
        with patch('release_h.web_approval.helper_path',return_value=self.helper), patch('release_h.web_approval.mac_session_unlocked',return_value=None), patch('release_h.web_approval.subprocess.run') as run:
            self.assertFalse(approve_web_origin('http://127.0.0.1:8765')); run.assert_not_called()
    def test_native_args_and_post_approval_lock_check(self):
        self.marker(1)
        with patch('release_h.web_approval.helper_path',return_value=self.helper), patch('release_h.web_approval.mac_session_unlocked',side_effect=[True,False]), patch('release_h.web_approval.subprocess.run') as run:
            run.return_value.returncode=0
            self.assertFalse(approve_web_origin('http://127.0.0.1:8765'))
            self.assertEqual(run.call_args.args[0],[str(self.helper),'--approve-web-origin','http://127.0.0.1:8765'])
            self.assertFalse(run.call_args.kwargs.get('shell',False))
