"""Static loopback preview with response-level framing protection."""
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]/'dist'
CSP="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src http://127.0.0.1:8766; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'"

class PreviewHandler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def log_message(self,*args): pass
    def end_headers(self):
        self.send_header('Content-Security-Policy',CSP)
        self.send_header('X-Frame-Options','DENY')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Cache-Control','no-store')
        super().end_headers()
    def translate_path(self,path):
        translated=Path(super().translate_path(path)).resolve()
        return str(translated if translated.is_relative_to(ROOT) else ROOT/'not-found')

if __name__=='__main__':
    server=HTTPServer(('127.0.0.1',8765),PreviewHandler)
    print('RELEASE H preview: http://127.0.0.1:8765/',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
