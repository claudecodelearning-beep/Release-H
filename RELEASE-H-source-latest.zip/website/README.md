# RELEASE H web experience

English responsive project website with an authorized local Mac Agent connection, a separate workflow simulation and optional Web Bluetooth control of a nearby SwitchBot Bot. No build step or npm dependencies are required.

## Benefits

- Reduce repetitive preparation: demonstrate app recovery, dual-display layouts and a Pomodoro session as one workflow.
- Replace some SwitchBot Hub functions: a compatible nearby computer can send Bot press commands over Bluetooth without a Hub. This does not replace infrared control, Matter bridging or Internet remote access.
- Keep human oversight: device selection and each physical press require explicit user action. Unconfirmed actions are not automatically retried.
- Keep device data local: no keys, device bindings or Mac remote-control endpoints are published.
- Choose your own launch list: open supported apps, custom websites and a PyCharm project through your own local Agent. Display-layout editing and custom Bot sequences remain planned.

## Roadmap: user-designed workflows with a local Agent

The full workflow editor and general-purpose installer remain planned. A simple launch-list editor is implemented: after connecting Agent, enable **Use my app selection**, select apps, enter up to five public http/https URLs, optionally choose a PyCharm project in a native Mac folder dialog, and save. **Start workflow** then opens those targets only, without Bot actions, screen layouts or the default Pomodoro. Uncheck the option to run the original full workflow.

Supported apps include Visual Studio Code, Terminal, Notes, Codex, Claude, Chrome, Safari, Music, Cursor, PyCharm, Calendar and Reminders. They must already be installed. A successful launch request does not prove a website loaded or an IDE finished loading its project. PyCharm project paths stay in the private Agent runtime directory; the website receives only a configured/not-configured flag. Preferences are saved only when you click Save; no browser localStorage or cloud sync is used. Reloading and reconnecting loads the saved list from this Mac.

The intended experience is:

1. Click **Start workflow** on the website. First-time users are guided to download, install and open RELEASE H Agent on their own Mac.
2. Grant only the macOS permissions needed for the selected actions, such as Accessibility, Automation and Bluetooth. Downloading the Agent does not automatically install it or grant these permissions.
3. Design a personal workflow by choosing supported actions, their settings and execution order—for example, open work apps, arrange displays, start a Pomodoro video and press a configured Bot.
4. Review and authorize the workflow locally, then request execution from the website. The Agent performs the approved actions on that user's computer.

Workflow settings, device bindings and any device credentials are intended to remain on the user's Mac—not in the public website, GitHub repository or shared installer. The Agent should accept only supported, explicitly authorized actions, not arbitrary shell commands from a webpage. Users must be able to revoke access or stop the Agent.

This design targets a website and Agent on the same computer. Controlling a home Mac from a phone elsewhere would require a separate authenticated remote-access design and is not included in this roadmap item.

## Run locally

```sh
npm run preview
```

Open http://127.0.0.1:8765 in Chrome on the Mac. `file://` module loading is not supported. Use HTTPS for hosting; localhost is also considered a secure browser context.

## What the page can do

- Detect the updated Agent on this Mac, request native authorization and start its existing workflow on an explicit click. Pairing does not start work; click Start workflow after approval.
- Display sanitized queued/running/waiting-for-unlock/completed/failed/unknown status for the current session's own request. A lost response does not trigger a new start.
- Simulate the Mac workflow, including pause/reset, software-only and lock/unlock scenarios.
- With explicit browser permission, connect to a nearby SwitchBot Bot, read its basic info and verify Press mode.
- After a separate user confirmation, issue one press and wait for the device acknowledgement. Timeout/disconnection never automatically retries.

## Privacy and boundaries

- The Agent bridge listens only on `127.0.0.1:8766` and accepts the exact local preview Origin `http://127.0.0.1:8765`. Public hosted origins are not enabled in this version. No Internet remote-control endpoint or cloud relay.
- Agent session tokens stay in Agent/tab memory, expire after 30 minutes without an accepted start or 8 hours total, and are discarded on reload. Disconnect revokes future requests; work already accepted can continue. A failed revoke request removes the local token but relies on server expiry for final cleanup.
- No pairing key/password form. Password-protected Bots are not supported.
- Device references, names and status remain in tab memory; nothing is put in localStorage, sent to a server or included in source. The browser itself may retain the user's Bluetooth grant until it is revoked in site settings.
- No analytics, remote fonts, third-party scripts or telemetry. Only the dedicated Agent client makes network requests, to the fixed loopback address. CSP permits only that connection. Hosting serves ordinary static files, without device data.
- No personal Mac paths, device MAC/UUID, Bot bindings, runtime logs or local secrets belong in this directory.
- The workflow demo never triggers hardware. Start workflow may run already-configured hardware through the Agent, including before desktop unlock. The independent Bluetooth card can also issue a manually confirmed press; starting an Agent workflow never invokes that card.
- Mac Chrome is the recommended browser; unsupported browsers show a message and keep real control disabled. Common iPhone browsers do not expose Web Bluetooth. This page is not an Internet remote-control bridge.
- A reported Bot acknowledgement is not proof that the appliance is now on.

## Verification

Use Node.js 20 or later. No dependency installation is needed.

```sh
npm test
npm run check
```

Protocol tests use a simulated GATT device; they do not establish actual hardware compatibility. Real hardware pairing and actuation are left to the owner.

Official references: [SwitchBot BLE Bot protocol](https://github.com/OpenWonderLabs/SwitchBotAPI-BLE/blob/latest/devicetypes/bot.md), [Chrome Web Bluetooth](https://developer.chrome.com/docs/capabilities/bluetooth).

## Upload to GitHub

Publish only the reviewed `dist/`, `tests/`, `scripts/preview.py`, `package.json`, this README and `.gitignore`. Exclude local hosting identity, Git metadata, environment files, runtime data and device bindings. No new release archive or online deployment is implied by this README. In the existing Release-H repository, this source can live under `website/` without replacing the Mac project.

## Updated Agent setup

The native source lives in the separate Mac project checkout. Run its existing local setup and build/install scripts on the destination Mac after reviewing the changes; the updated wrapper enables `agent --web-control`. This implementation does not automatically replace an installed Agent. The current app build still depends on that Mac's checkout and Python environment, so do not publish it as a portable installer.

The native dialog names the exact website Origin and asks whether it may start the configured workflow during the current session. Rejecting or timing out grants no session. Existing system Accessibility, Automation and Bluetooth permissions still apply.

The preview script sends `frame-ancestors 'none'` and `X-Frame-Options: DENY`; top-level checks also disable control in embedded pages. Any future hosting configuration must preserve these protections before an additional Origin is enabled locally.

Uploading source does not automatically host the page. For static hosting, publish the contents of `dist/` over HTTPS. All assets use relative paths, so the site can also run under a repository subpath. Do not add device keys, `.env` files or native-agent runtime files to the repository.

The automated tests use simulated Bluetooth transport and static source checks. They are not a security audit or proof of compatibility with every Bot firmware. Before a real press, the owner must verify the mounting, appliance state and clear space around the actuator.
