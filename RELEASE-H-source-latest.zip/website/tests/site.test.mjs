import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile, readdir} from 'node:fs/promises';

const root = new URL('../dist/', import.meta.url);
const files = await readdir(root);
const sources = new Map(await Promise.all(files.map(async name => [name, await readFile(new URL(name, root), 'utf8')])));
const html = sources.get('index.html');

test('all shipped page copy is English, including dynamic messages', () => {
  assert.match(html, /<html lang="en">/);
  for (const [name, source] of sources) assert.doesNotMatch(source, /\p{Script=Han}/u, name);
});

test('page assets and in-page links resolve, with unique element IDs', () => {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
  assert.equal(new Set(ids).size, ids.length);
  for (const [, path] of html.matchAll(/(?:src|href)="\.\/([^"]+)"/g)) assert.ok(sources.has(path.split('?')[0]), path);
  for (const [, id] of html.matchAll(/href="#([^"]+)"/g)) assert.ok(ids.includes(id), id);
  for (const [, id] of sources.get('app.js').matchAll(/\$\('([^']+)'\)/g)) assert.ok(ids.includes(id), id);
});

test('static privacy guardrails: no remote-control calls or persistent device storage', () => {
  assert.match(html, /connect-src http:\/\/127\.0\.0\.1:8766;/);
  assert.match(html, /name="referrer" content="no-referrer"/);
  for (const [name, source] of sources) {
    if (!/\.(?:mjs|js)$/.test(name)) continue;
    if (name !== 'agent-client.mjs') assert.doesNotMatch(source, /\b(?:fetch|WebSocket|XMLHttpRequest|sendBeacon)\s*\(/, name);
    assert.doesNotMatch(source, /\b(?:localStorage|sessionStorage|indexedDB)\b|document\.cookie/, name);
  }
});

test('real press starts disabled and has a separate human confirmation', () => {
  assert.match(html, /id="press-bot" disabled/);
  assert.match(html, /<dialog id="press-dialog"/);
  assert.match(html, /id="confirm-press" type="button"/);
  assert.match(html, /value="cancel" autofocus/);
  assert.match(html, /This demo does not operate real apps or devices/);
});
