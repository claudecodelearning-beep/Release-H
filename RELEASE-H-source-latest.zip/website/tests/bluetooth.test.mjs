import test from 'node:test';
import assert from 'node:assert/strict';
let BotClient;
try { ({BotClient} = await import('../dist/bluetooth.mjs')); } catch { /* red-first */ }

function fakeDevice({info = [1,100,44,100,0,0,0,161,0,0,0,72,0], pressReply = [1,255,0]} = {}) {
  const notifications = new EventTarget();
  notifications.startNotifications = async () => notifications;
  const device = new EventTarget();
  const writes = [];
  const writer = {properties: {write:true}, async writeValueWithResponse(bytes) {
    writes.push(Array.from(bytes));
    const reply = bytes[1] === 2 ? info : pressReply;
    if (reply) queueMicrotask(() => {
      notifications.value = new DataView(Uint8Array.from(reply).buffer);
      notifications.dispatchEvent(new Event('characteristicvaluechanged'));
    });
  }};
  device.name = 'Test Bot';
  device.gatt = {connected:false, async connect() {
    this.connected = true; return this;
  }, disconnect() {
    this.connected = false; device.dispatchEvent(new Event('gattserverdisconnected'));
  }, async getPrimaryService() {
    return {getCharacteristic: async id => id.includes('0002-') ? writer : notifications};
  }};
  return {writes, device, bluetooth:{requestDevice: async () => device}};
}

test('connect reads device info only; explicit confirmation sends one press', async () => {
  assert.equal(typeof BotClient, 'function', 'BLE client not implemented');
  const fixture = fakeDevice();
  const bot = new BotClient({bluetooth:fixture.bluetooth});
  const info = await bot.connect();
  assert.equal(info.battery, 100);
  assert.deepEqual(fixture.writes, [[0x57,0x02]]);
  await assert.rejects(bot.press(), /confirm this physical press/);
  await bot.press({confirmed:true});
  assert.deepEqual(fixture.writes, [[0x57,0x02],[0x57,0x01,0x00]]);
  bot.disconnect();
});

test('non-Bot, switch-mode and password-protected devices never receive action', async () => {
  assert.equal(typeof BotClient, 'function');
  for (const info of [[7], [1,100,44,100,0,0,0,161,0,16,0,72,128], [1,100,44,100,0,0,0,161,0,0,0,84,0]]) {
    const fixture = fakeDevice({info});
    const bot = new BotClient({bluetooth:fixture.bluetooth});
    await assert.rejects(bot.connect());
    await assert.rejects(bot.press({confirmed:true}));
    assert.deepEqual(fixture.writes, [[0x57,0x02]]);
  }
});

test('duplicate in-flight presses are rejected and unacknowledged actions never retry', async () => {
  assert.equal(typeof BotClient, 'function');
  const fixture = fakeDevice({pressReply:null});
  const bot = new BotClient({bluetooth:fixture.bluetooth, timeoutMs:20});
  await bot.connect();
  const first = bot.press({confirmed:true});
  await assert.rejects(bot.press({confirmed:true}));
  await assert.rejects(first, /outcome unconfirmed/);
  assert.deepEqual(fixture.writes, [[0x57,0x02],[0x57,0x01,0x00]]);
  assert.equal(fixture.device.gatt.connected, false);
});

test('disconnecting before acknowledgement reports unknown outcome, never success', async () => {
  assert.equal(typeof BotClient, 'function');
  const fixture = fakeDevice({pressReply:null});
  const bot = new BotClient({bluetooth:fixture.bluetooth});
  await bot.connect();
  const pending = bot.press({confirmed:true});
  fixture.device.gatt.disconnect();
  await assert.rejects(pending, /outcome unconfirmed/);
  assert.equal(fixture.writes.length, 2);
});
