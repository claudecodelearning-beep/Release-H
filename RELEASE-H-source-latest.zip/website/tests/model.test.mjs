import test from 'node:test';
import assert from 'node:assert/strict';
let model;
try { model = await import('../dist/model.mjs'); } catch { model = {}; }

test('a simulation starts visibly labeled and finishes every step', () => {
  assert.equal(typeof model.createSimulation, 'function', 'Simulation has not been implemented');
  let state = model.createSimulation('full');
  assert.equal(state.phase, 'idle');
  assert.equal(state.isSimulation, true);
  state = model.startSimulation(state);
  for (let n = 0; n < 10; n++) state = model.advanceSimulation(state);
  assert.equal(state.phase, 'completed');
  assert.equal(state.steps.every(step => step.status === 'completed'), true);
});

test('pause freezes progress and resume continues from the same step', () => {
  assert.equal(typeof model.togglePause, 'function', 'Pause has not been implemented');
  let state = model.advanceSimulation(model.startSimulation(model.createSimulation('full')));
  state = model.togglePause(state);
  assert.equal(state.phase, 'paused');
  assert.deepEqual(model.advanceSimulation(state), state);
  const index = state.active;
  state = model.togglePause(state);
  assert.equal(state.phase, 'running');
  assert.equal(state.active, index);
});

test('locked scenario waits after simulated hardware until explicit unlock', () => {
  assert.equal(typeof model.unlockSimulation, 'function', 'Unlock simulation has not been implemented');
  let state = model.startSimulation(model.createSimulation('locked'));
  state = model.advanceSimulation(model.advanceSimulation(state));
  assert.equal(state.phase, 'locked');
  assert.equal(state.steps[1].id, 'hardware');
  assert.equal(state.steps[1].status, 'completed');
  assert.deepEqual(model.advanceSimulation(state), state);
  state = model.unlockSimulation(state);
  assert.equal(state.phase, 'running');
  assert.equal(state.steps[2].status, 'running');
});

test('desktop-only scenario excludes physical actions and reset clears progress', () => {
  assert.equal(typeof model.createSimulation, 'function', 'Scenario selection has not been implemented');
  let state = model.createSimulation('desktop');
  assert.equal(state.steps.some(step => step.id === 'hardware'), false);
  state = model.advanceSimulation(model.startSimulation(state));
  const reset = model.createSimulation(state.scenario);
  assert.equal(reset.phase, 'idle');
  assert.equal(reset.steps.every(step => step.status === 'pending'), true);
});
