import test from 'node:test';
import assert from 'node:assert/strict';
import {AgentClient} from '../dist/agent-client.mjs';

const ID='a9986e2b-a11f-4b1b-a783-f17d998179cc';
const reply=(body,status=200)=>({ok:status>=200&&status<300,status,json:async()=>body});
function fixture({loseStart=false,deny=false}={}) {
  const requests=[]; let starts=0;
  const fetch=async(url,options)=>{
    requests.push({url,options});
    if(url.endsWith('/health'))return reply({product:'release-h-agent',protocol:1,available:true});
    if(options.method==='DELETE')return reply(null,204);
    if(url.endsWith('/session'))return deny?reply({error:'approval_denied'},403):reply({token:'a'.repeat(43),expires_in:28800},201);
    if(url.endsWith('/start')){starts++; if(loseStart)throw new Error('PRIVATE SERVER DETAIL'); return reply({request_id:ID,status:'queued'},202);}
    return reply({request_id:ID,status:'completed'});
  };
  const states=[];
  return {client:new AgentClient({fetch,uuid:()=>ID,onState:state=>states.push(state)}),requests,states,starts:()=>starts};
}

test('detect and pair never launch; explicit start sends one fixed request',async()=>{
  const f=fixture(); await f.client.detect(); await f.client.pair();
  assert.equal(f.starts(),0); await f.client.start(); assert.equal(f.starts(),1);
  assert.equal(f.states.at(-1).executionStatus,'queued');
  for(const {url,options} of f.requests){
    assert.ok(url.startsWith('http://127.0.0.1:8766/v1/'));
    assert.equal(options.credentials,'omit');assert.equal(options.redirect,'error');
    assert.equal(options.referrerPolicy,'no-referrer');assert.ok(!url.includes('a'.repeat(43)));
  }
  assert.ok(!JSON.stringify(f.states).includes('a'.repeat(43)));
  assert.deepEqual(JSON.parse(f.requests.find(r=>r.url.endsWith('/start')).options.body),{action:'start-work',request_id:ID});
});

test('lost start response is unknown; status recovery does not POST again',async()=>{
  const f=fixture({loseStart:true});await f.client.detect();await f.client.pair();await f.client.start();
  assert.equal(f.states.at(-1).phase,'unknown');
  await f.client.start();assert.equal(f.starts(),1);
  await f.client.status();assert.equal(f.states.at(-1).executionStatus,'completed');assert.equal(f.starts(),1);
});

test('denied native consent cannot enable a start',async()=>{
  const f=fixture({deny:true});await f.client.detect();await f.client.pair();await f.client.start();
  assert.equal(f.starts(),0);assert.equal(f.client.authorized,false);
});

test('disconnect clears authorization even when revoke cannot reach server',async()=>{
  const f=fixture();await f.client.pair();await f.client.disconnect();await f.client.start();
  assert.equal(f.client.authorized,false);assert.equal(f.starts(),0);
});

test('malformed service data is sanitized and cannot impersonate an Agent',async()=>{
  const states=[];const client=new AgentClient({fetch:async()=>reply({product:'other',protocol:1,available:true,detail:'PRIVATE'}),onState:s=>states.push(s)});
  await client.detect();assert.equal(states.at(-1).phase,'unavailable');assert.ok(!JSON.stringify(states).includes('PRIVATE'));
});

test('a disposed client discards a late pair response',async()=>{
  let release;const states=[];
  const client=new AgentClient({fetch:()=>new Promise(r=>{release=r;}),onState:s=>states.push(s)});
  const pending=client.pair();client.dispose();release(reply({token:'b'.repeat(43),expires_in:28800},201));await pending;
  assert.equal(client.authorized,false);
});

test('Disconnect removes authority immediately while network revoke is pending',async()=>{
  let release, starts=0;const states=[];
  const client=new AgentClient({uuid:()=>ID,onState:s=>states.push(s),fetch:async(url,opts)=>{
    if(opts.method==='DELETE')return new Promise(r=>{release=r;});
    if(url.endsWith('/start')){starts++;return reply({request_id:ID,status:'queued'},202);}
    return reply({token:'c'.repeat(43),expires_in:28800},201);
  }});
  await client.pair();const revoke=client.disconnect();
  assert.equal(client.authorized,false);await client.start();assert.equal(starts,0);
  release(reply(null,204));await revoke;
});

test('late start response cannot restore a revoked request state',async()=>{
  let release;const states=[];
  const client=new AgentClient({uuid:()=>ID,onState:s=>states.push(s),fetch:async(url,opts)=>{
    if(opts.method==='DELETE')return reply(null,204);
    if(url.endsWith('/start'))return new Promise(r=>{release=r;});
    return reply({token:'d'.repeat(43),expires_in:28800},201);
  }});
  await client.pair();const pending=client.start();await client.disconnect();
  release(reply({request_id:ID,status:'queued'},202));await pending;
  assert.equal(states.at(-1).phase,'disconnected');assert.equal(client.authorized,false);
});

test('expired click asks for authorization and never sends a start',async()=>{
  let now=0;const states=[],requests=[];
  const client=new AgentClient({clock:()=>now,onState:s=>states.push(s),fetch:async(url)=>{requests.push(url);return reply({token:'e'.repeat(43),expires_in:28800},201);}});
  await client.pair();now=1800000;await client.start();
  assert.equal(states.at(-1).phase,'needs_authorization');assert.equal(requests.length,1);
});

test('late failed revoke cannot overwrite a newly approved session',async()=>{
  let fail;const states=[];
  const client=new AgentClient({onState:s=>states.push(s),fetch:async(url,opts)=>{
    if(opts.method==='DELETE')return new Promise((resolve,reject)=>{fail=reject;});
    return reply({token:'f'.repeat(43),expires_in:28800},201);
  }});
  await client.pair();const pending=client.disconnect();await client.pair();fail(new Error('offline'));await pending;
  assert.equal(client.authorized,true);assert.equal(states.at(-1).phase,'connected');
});

test('custom launch sends only structured selections to the local Agent',async()=>{
  const f=fixture();await f.client.pair();
  const selection={apps:['cursor','music'],websites:['https://example.com'],project:false};
  await f.client.start(selection);
  const request=f.requests.find(r=>r.url.endsWith('/start'));
  assert.deepEqual(JSON.parse(request.options.body),{action:'start-work',request_id:ID,selection});
  assert.equal(request.url,'http://127.0.0.1:8766/v1/start');
  assert.equal(request.options.credentials,'omit');
  assert.ok(!JSON.stringify(f.states).includes('example.com'));
});
