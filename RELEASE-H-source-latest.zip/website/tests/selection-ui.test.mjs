import test from 'node:test';
import assert from 'node:assert/strict';
import {mountSelectionEditor} from '../dist/selection-ui.js';

test('configuration still loading or failed never falls back to the full workflow',async()=>{
  const fields=new Map();
  const root={getElementById(id){if(!fields.has(id))fields.set(id,{checked:false,disabled:true,value:'',textContent:'',addEventListener(){},replaceChildren(){},querySelectorAll(){return [];}});return fields.get(id);}};
  let reject;
  const editor=mountSelectionEditor({root,client:{loadSelection:()=>new Promise((resolve,fail)=>{reject=fail;})}});
  assert.throws(()=>editor.get());
  const loading=editor.connect();assert.throws(()=>editor.get());
  reject(new Error('unavailable'));await loading;assert.throws(()=>editor.get());
});
